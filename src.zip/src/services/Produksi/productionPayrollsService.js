// =====================================================
// Production Payrolls Service
// Generate payroll dari work log completed
// =====================================================

import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../../firebase";
import { calculatePayrollAmounts } from "../../constants/productionPayrollOptions";
import { getCompletedProductionWorkLogs } from "./productionWorkLogsService";

const COLLECTION_NAME = "production_payrolls";
const WORK_LOG_COLLECTION_NAME = "production_work_logs";

// =====================================================
// ACTIVE / GUARDED - sort payroll tanpa index tambahan
// Fungsi blok:
// - menyamakan urutan payroll terbaru di query utama dan fallback;
// - mendukung Timestamp Firestore maupun string tanggal lama.
// Alasan blok ini dipakai:
// - fallback plain collection tidak boleh membutuhkan composite index.
// Status:
// - aktif dipakai; bukan legacy.
// =====================================================
const getPayrollSortTime = (value) => {
  if (!value) return 0;
  if (typeof value.toDate === "function") return value.toDate().getTime();

  const parsed = new Date(value).getTime();
  return Number.isNaN(parsed) ? 0 : parsed;
};

const sortProductionPayrollsNewestFirst = (items = []) =>
  [...items].sort((a, b) => {
    const dateDiff = getPayrollSortTime(b.payrollDate) - getPayrollSortTime(a.payrollDate);
    if (dateDiff !== 0) return dateDiff;
    return String(b.payrollNumber || "").localeCompare(String(a.payrollNumber || ""));
  });

const normalizePayload = (values = {}, currentUser = null, isEdit = false) => {
  const totals = calculatePayrollAmounts(values);

  const payload = {
    payrollNumber: String(values.payrollNumber || "")
      .trim()
      .toUpperCase(),
    payrollDate: values.payrollDate || null,

    workLogId: values.workLogId || "",
    workNumber: String(values.workNumber || "").trim(),

    bomId: values.bomId || "",
    bomCode: String(values.bomCode || "").trim(),

    targetType: values.targetType || "",
    targetId: values.targetId || "",
    targetCode: String(values.targetCode || "").trim(),
    targetName: String(values.targetName || "").trim(),

    stepId: values.stepId || "",
    stepCode: String(values.stepCode || "").trim(),
    stepName: String(values.stepName || "").trim(),
    sequenceNo: Number(values.sequenceNo || 1),

    workerId: values.workerId || "",
    workerCode: String(values.workerCode || "").trim(),
    workerName: String(values.workerName || "").trim(),

    payrollMode: values.payrollMode || "per_qty",
    payrollRate: Number(values.payrollRate || 0),
    payrollQtyBase: Number(values.payrollQtyBase || 1),
    payrollOutputBasis: values.payrollOutputBasis || "good_qty",

    totalWorkLogOutputQty: Number(values.totalWorkLogOutputQty || 0),
    workedQty: Number(values.workedQty || 0),
    outputQtyUsed: Number(values.outputQtyUsed || 0),
    payableQtyFactor: totals.payableQtyFactor,

    amountCalculated: totals.amountCalculated,
    bonusAmount: Number(values.bonusAmount || 0),
    deductionAmount: Number(values.deductionAmount || 0),
    finalAmount: totals.finalAmount,

    sharedWorkLog: Boolean(values.sharedWorkLog),
    teamWorkerCount: Number(values.teamWorkerCount || 1),

    status: values.status || "draft",
    paymentStatus: values.paymentStatus || "unpaid",
    paidAt: values.paidAt || null,

    notes: String(values.notes || "").trim(),
    calculationNotes: String(values.calculationNotes || "").trim(),

    updatedAt: serverTimestamp(),
    updatedBy:
      currentUser?.email ||
      currentUser?.displayName ||
      currentUser?.uid ||
      "system",
  };

  if (!isEdit) {
    payload.createdAt = serverTimestamp();
    payload.createdBy =
      currentUser?.email ||
      currentUser?.displayName ||
      currentUser?.uid ||
      "system";
  }

  return payload;
};

export const validateProductionPayroll = (values = {}) => {
  const errors = {};

  if (!String(values.payrollNumber || "").trim()) {
    errors.payrollNumber = "Nomor payroll wajib diisi";
  }

  if (!values.payrollDate) {
    errors.payrollDate = "Tanggal payroll wajib diisi";
  }

  if (!values.workLogId) {
    errors.workLogId = "Work log wajib dipilih";
  }

  if (!values.workerName && !values.workerId) {
    errors.workerId = "Karyawan wajib dipilih";
  }

  if (Number(values.outputQtyUsed || 0) < 0) {
    errors.outputQtyUsed = "Output qty tidak boleh negatif";
  }

  return errors;
};

export const getPayrollReferenceData = async () => {
  const [completedWorkLogs, employeesResult] = await Promise.all([
    getCompletedProductionWorkLogs(),
    (async () => {
      try {
        const snapshot = await getDocs(collection(db, "production_employees"));
        return {
          items: snapshot.docs
            .map((documentItem) => ({ id: documentItem.id, ...documentItem.data() }))
            .filter((item) => item.isActive !== false)
            .sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""))),
        };
      } catch (error) {
        console.error("Gagal memuat referensi karyawan payroll produksi", error);
        return { items: [] };
      }
    })(),
  ]);

  return {
    completedWorkLogs,
    employees: employeesResult.items,
  };
};

export const buildPayrollDraftFromWorkLog = (workLog, employee = null) => {
  const basisOutput =
    workLog?.goodQty && Number(workLog.goodQty || 0) > 0
      ? Number(workLog.goodQty || 0)
      : Number(workLog.actualOutputQty || 0);

  let payrollMode = "per_qty";
  let payrollRate = 0;
  let payrollQtyBase = 1;
  let payrollOutputBasis = "good_qty";

  if (employee?.useCustomPayrollRate) {
    payrollMode = employee.customPayrollMode || "per_qty";
    payrollRate = Number(employee.customPayrollRate || 0);
    payrollQtyBase = Number(employee.customPayrollQtyBase || 1);
    payrollOutputBasis = employee.customPayrollOutputBasis || "good_qty";
  }

  const outputQtyUsed = basisOutput;
  const calculated = calculatePayrollAmounts({
    payrollMode,
    payrollRate,
    payrollQtyBase,
    outputQtyUsed,
    bonusAmount: 0,
    deductionAmount: 0,
  });

  return {
    workLogId: workLog?.id || "",
    workNumber: workLog?.workNumber || "",

    bomId: workLog?.bomId || "",
    bomCode: workLog?.bomCode || "",

    targetType: workLog?.targetType || "",
    targetId: workLog?.targetId || "",
    targetCode: workLog?.targetCode || "",
    targetName: workLog?.targetName || "",

    stepId: workLog?.stepId || "",
    stepCode: workLog?.stepCode || "",
    stepName: workLog?.stepName || "",
    sequenceNo: Number(workLog?.sequenceNo || 1),

    workerId: employee?.id || "",
    workerCode: employee?.code || "",
    workerName: employee?.name || "",

    payrollMode,
    payrollRate,
    payrollQtyBase,
    payrollOutputBasis,

    totalWorkLogOutputQty: basisOutput,
    workedQty: basisOutput,
    outputQtyUsed,
    payableQtyFactor: calculated.payableQtyFactor,

    amountCalculated: calculated.amountCalculated,
    bonusAmount: 0,
    deductionAmount: 0,
    finalAmount: calculated.finalAmount,

    sharedWorkLog: (workLog?.workerIds || []).length > 1,
    teamWorkerCount: Number(workLog?.workerCount || 1),

    status: "draft",
    paymentStatus: "unpaid",
    paidAt: null,

    notes: "",
    calculationNotes: "Draft payroll dibuat dari work log completed",
  };
};

// =====================================================
// SECTION: Sinkronisasi summary Payroll -> Work Log
// Fungsi:
// - menjaga Work Log detail menampilkan labor/final cost dari payroll line terbaru
// - mencegah user melihat labor 0 padahal payroll line sudah ada
// Status:
// - aktif dipakai oleh flow create/update/status payroll
// - kandidat cleanup hanya jika nanti summary costing Work Log dipisah penuh ke read-model khusus
// =====================================================
const syncWorkLogPayrollSummary = async (workLogId) => {
  if (!workLogId) return;

  const workLogRef = doc(db, WORK_LOG_COLLECTION_NAME, workLogId);
  const workLogSnap = await getDoc(workLogRef);

  if (!workLogSnap.exists()) return;

  const workLogData = workLogSnap.data() || {};
  const payrollSnapshot = await getDocs(
    query(collection(db, COLLECTION_NAME), where("workLogId", "==", workLogId)),
  );

  const payrollLines = payrollSnapshot.docs.map((item) => ({
    id: item.id,
    ...item.data(),
  }));

  const activeLines = payrollLines.filter((line) => line.status !== "cancelled");
  const paidLines = activeLines.filter((line) => line.paymentStatus === "paid");
  const payrollIds = activeLines.map((line) => line.id);
  const payrollFinalAmount = activeLines.reduce(
    (sum, line) => sum + Number(line.finalAmount || 0),
    0,
  );

  const materialCostActual = Number(workLogData.materialCostActual || 0);
  const overheadCostActual = Number(workLogData.overheadCostActual || 0);
  const goodQty = Number(workLogData.goodQty || 0);
  const totalCostActual = materialCostActual + payrollFinalAmount + overheadCostActual;
  const costPerGoodUnit = goodQty > 0 ? totalCostActual / goodQty : 0;

  await updateDoc(workLogRef, {
    payrollCalculated: activeLines.length > 0,
    payrollCalculationStatus:
      activeLines.length === 0
        ? "pending"
        : paidLines.length === activeLines.length
          ? "posted"
          : "calculated",
    payrollIds,
    payrollLineCount: activeLines.length,
    paidPayrollLineCount: paidLines.length,
    payrollFinalAmount,
    laborCostActual: payrollFinalAmount,
    totalCostActual,
    costPerGoodUnit,
    updatedAt: serverTimestamp(),
    updatedBy: "system",
  });
};

export const getAllProductionPayrolls = async () => {
  // =====================================================
  // ACTIVE / FINAL - QUERY UTAMA PAYROLL
  // Fungsi blok:
  // - memuat payroll produksi untuk summary read-only di halaman karyawan;
  // - urutan server-side dipakai bila composite index sudah tersedia.
  // Alasan blok ini dipakai:
  // - payroll adalah data pendukung, bukan syarat agar employee tampil.
  // Status:
  // - aktif dipakai; bukan legacy.
  // =====================================================
  try {
    const q = query(
      collection(db, COLLECTION_NAME),
      orderBy("payrollDate", "desc"),
      orderBy("payrollNumber", "desc"),
    );

    const snapshot = await getDocs(q);

    return sortProductionPayrollsNewestFirst(
      snapshot.docs.map((item) => ({
        id: item.id,
        ...item.data(),
      })),
    );
  } catch (error) {
    // =====================================================
    // ACTIVE / GUARDED - FALLBACK PAYROLL TANPA INDEX
    // Fungsi blok:
    // - membaca plain collection jika query dengan dua orderBy membutuhkan index;
    // - sort dilakukan di client agar halaman Karyawan Produksi tidak ikut kosong.
    // Alasan blok ini dipakai:
    // - fallback ini menjaga data pendukung payroll tidak menjatuhkan data utama employee.
    // Status:
    // - aktif sebagai guard; kandidat cleanup hanya jika index Firestore sudah dibuat.
    // =====================================================
    console.error("Query payroll produksi utama gagal, pakai fallback plain collection", error);
    const snapshot = await getDocs(collection(db, COLLECTION_NAME));

    return sortProductionPayrollsNewestFirst(
      snapshot.docs.map((item) => ({
        id: item.id,
        ...item.data(),
      })),
    );
  }
};

export const getProductionPayrollById = async (id) => {
  const ref = doc(db, COLLECTION_NAME, id);
  const snapshot = await getDoc(ref);

  if (!snapshot.exists()) {
    throw new Error("Data payroll produksi tidak ditemukan");
  }

  return {
    id: snapshot.id,
    ...snapshot.data(),
  };
};

export const isPayrollNumberExists = async (
  payrollNumber,
  excludeId = null,
) => {
  const normalized = String(payrollNumber || "")
    .trim()
    .toUpperCase();
  if (!normalized) return false;

  const snapshot = await getDocs(
    query(
      collection(db, COLLECTION_NAME),
      where("payrollNumber", "==", normalized),
    ),
  );

  if (snapshot.empty) return false;

  const found = snapshot.docs.find((item) => item.id !== excludeId);
  return Boolean(found);
};

export const createProductionPayroll = async (values, currentUser = null) => {
  const errors = validateProductionPayroll(values);

  if (Object.keys(errors).length > 0) {
    throw { type: "validation", errors };
  }

  const exists = await isPayrollNumberExists(values.payrollNumber);
  if (exists) {
    throw {
      type: "validation",
      errors: {
        payrollNumber: "Nomor payroll sudah digunakan",
      },
    };
  }

  const payload = normalizePayload(values, currentUser, false);
  const result = await addDoc(collection(db, COLLECTION_NAME), payload);
  await syncWorkLogPayrollSummary(payload.workLogId || values.workLogId || "");
  return result.id;
};

export const updateProductionPayroll = async (
  id,
  values,
  currentUser = null,
) => {
  const currentRecord = await getProductionPayrollById(id);
  const errors = validateProductionPayroll(values);

  if (Object.keys(errors).length > 0) {
    throw { type: "validation", errors };
  }

  const exists = await isPayrollNumberExists(values.payrollNumber, id);
  if (exists) {
    throw {
      type: "validation",
      errors: {
        payrollNumber: "Nomor payroll sudah digunakan",
      },
    };
  }

  const payload = normalizePayload(values, currentUser, true);
  await updateDoc(doc(db, COLLECTION_NAME, id), payload);
  await syncWorkLogPayrollSummary(currentRecord.workLogId || "");
  if ((payload.workLogId || "") !== (currentRecord.workLogId || "")) {
    await syncWorkLogPayrollSummary(payload.workLogId || "");
  }
  return id;
};

export const updatePayrollStatus = async (
  id,
  status,
  paymentStatus,
  extra = {},
) => {
  const currentRecord = await getProductionPayrollById(id);
  await updateDoc(doc(db, COLLECTION_NAME, id), {
    status,
    paymentStatus,
    ...extra,
    updatedAt: serverTimestamp(),
    updatedBy: "system",
  });

  await syncWorkLogPayrollSummary(currentRecord.workLogId || "");

  return id;
};
