import {
  addDoc,
  collection,
  doc,
  getDocs,
  onSnapshot,
  serverTimestamp,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../../firebase';

// -----------------------------------------------------------------------------
// Collection supplier yang aktif dipakai aplikasi.
// supplierPurchases = master supplier baru.
// suppliers = fallback schema lama jika masih ada data lama tersisa.
// -----------------------------------------------------------------------------
const SUPPLIER_MASTER_COLLECTION = 'supplierPurchases';
const LEGACY_SUPPLIER_COLLECTION = 'suppliers';
const SUPPLIER_MASTER_COLLECTIONS = [SUPPLIER_MASTER_COLLECTION, LEGACY_SUPPLIER_COLLECTION];
const RAW_MATERIAL_COLLECTION = 'raw_materials';

// -----------------------------------------------------------------------------
// Helper trim aman supaya normalisasi string konsisten di semua fungsi.
// -----------------------------------------------------------------------------
const safeTrim = (value) => String(value || '').trim();

// -----------------------------------------------------------------------------
// Helper key normalisasi untuk dedupe nama supplier lintas schema.
// -----------------------------------------------------------------------------
const normalizeKey = (value) =>
  safeTrim(value)
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

// -----------------------------------------------------------------------------
// Dedupe array string tanpa peduli kapital/spasi.
// -----------------------------------------------------------------------------
const uniqueStrings = (values = []) => {
  const seen = new Set();

  return (values || [])
    .flat()
    .map((value) => safeTrim(value))
    .filter((value) => {
      if (!value) return false;

      const normalizedValue = normalizeKey(value);
      if (seen.has(normalizedValue)) return false;

      seen.add(normalizedValue);
      return true;
    });
};

// -----------------------------------------------------------------------------
// Ambil nama supplier terbaik dari berbagai kemungkinan field lama dan baru.
// -----------------------------------------------------------------------------
export const getSupplierDisplayName = (supplier = {}) => {
  return (
    safeTrim(supplier.storeName) ||
    safeTrim(supplier.name) ||
    safeTrim(supplier.supplierName) ||
    safeTrim(supplier.title) ||
    safeTrim(supplier.item) ||
    'Supplier tanpa nama'
  );
};

// -----------------------------------------------------------------------------
// Ambil link supplier terbaik dari field lama dan baru.
// -----------------------------------------------------------------------------
export const getSupplierLink = (supplier = {}) => {
  return (
    safeTrim(supplier.storeLink) ||
    safeTrim(supplier.link) ||
    safeTrim(supplier.url) ||
    safeTrim(supplier.shopLink) ||
    safeTrim(supplier.supplierLink) ||
    ''
  );
};

// -----------------------------------------------------------------------------
// Alias kompatibilitas lama supaya file yang belum sempat diganti tidak whitescreen.
// -----------------------------------------------------------------------------
export const getSupplierStoreLink = getSupplierLink;

// -----------------------------------------------------------------------------
// Ambil kategori supplier dari field lama maupun baru.
// -----------------------------------------------------------------------------
const getSupplierCategory = (supplier = {}) => {
  return safeTrim(supplier.category || supplier.description || supplier.type || supplier.note || '');
};

// -----------------------------------------------------------------------------
// Label select supplier agar konsisten di dropdown form.
// -----------------------------------------------------------------------------
export const buildSupplierDisplayLabel = (supplier = {}) => {
  const supplierName = getSupplierDisplayName(supplier);
  const supplierCategory = getSupplierCategory(supplier);

  if (!supplierCategory || normalizeKey(supplierCategory) === normalizeKey(supplierName)) {
    return supplierName;
  }

  return `${supplierName} • ${supplierCategory}`;
};

// -----------------------------------------------------------------------------
// Alias label dropdown baru agar kompatibel dengan patch sebelumnya.
// -----------------------------------------------------------------------------
export const getSupplierOptionLabel = (supplier = {}) => {
  const baseLabel = buildSupplierDisplayLabel(supplier);
  return isLegacyMaterialSupplierRecord(supplier) ? `${baseLabel} (data lama)` : baseLabel;
};

// -----------------------------------------------------------------------------
// Cek supplier master aktif yang aman untuk diupdate/hapus langsung.
// -----------------------------------------------------------------------------
export const isManagedSupplierRecord = (supplier = {}) => {
  return supplier.sourceCollection === SUPPLIER_MASTER_COLLECTION;
};

// -----------------------------------------------------------------------------
// Alias baru dari patch sebelumnya.
// -----------------------------------------------------------------------------
export const isMasterSupplierRecord = isManagedSupplierRecord;

// -----------------------------------------------------------------------------
// Cek supplier fallback lama hasil turunan dari bahan baku.
// -----------------------------------------------------------------------------
export const isLegacyMaterialSupplierRecord = (supplier = {}) => {
  return supplier.sourceCollection === RAW_MATERIAL_COLLECTION;
};

// -----------------------------------------------------------------------------
// Helper id supplier yang aman disimpan ke database.
// Id fallback legacy:* tidak boleh disimpan sebagai supplierId permanen.
// -----------------------------------------------------------------------------
export const getSupplierReferenceId = (supplier = {}, fallbackId = null) => {
  const candidate =
    safeTrim(supplier.masterSupplierId) ||
    safeTrim(supplier.firestoreSupplierId) ||
    safeTrim(supplier.id) ||
    safeTrim(fallbackId);

  if (!candidate) return null;
  if (String(candidate).startsWith('legacy:')) return null;
  if (isLegacyMaterialSupplierRecord(supplier)) return null;
  return candidate;
};

// -----------------------------------------------------------------------------
// Dedupe detail material supplier berdasarkan materialId / nama material.
// -----------------------------------------------------------------------------
const uniqueMaterialDetails = (details = []) => {
  const materialMap = new Map();

  (details || []).forEach((detail = {}) => {
    const materialId = safeTrim(detail.materialId);
    const materialName = safeTrim(detail.materialName);
    const productLink = safeTrim(detail.productLink);
    const note = safeTrim(detail.note);
    const referencePrice = Math.round(Number(detail.referencePrice || 0));

    const dedupeKey =
      materialId ||
      normalizeKey(materialName) ||
      normalizeKey(productLink) ||
      `detail-${materialMap.size}`;

    const existingDetail = materialMap.get(dedupeKey);

    if (!existingDetail) {
      materialMap.set(dedupeKey, {
        materialId,
        materialName,
        productLink,
        note,
        referencePrice,
      });
      return;
    }

    materialMap.set(dedupeKey, {
      ...existingDetail,
      materialId: existingDetail.materialId || materialId,
      materialName: existingDetail.materialName || materialName,
      productLink: existingDetail.productLink || productLink,
      note: existingDetail.note || note,
      referencePrice: existingDetail.referencePrice || referencePrice,
    });
  });

  return Array.from(materialMap.values());
};

// -----------------------------------------------------------------------------
// Normalisasi detail material dari dokumen supplier master / schema lama.
// -----------------------------------------------------------------------------
const normalizeMasterMaterialDetails = (supplier = {}) => {
  if (Array.isArray(supplier.materialDetails) && supplier.materialDetails.length > 0) {
    return uniqueMaterialDetails(supplier.materialDetails);
  }

  if (safeTrim(supplier.materialId) || safeTrim(supplier.materialName)) {
    return uniqueMaterialDetails([
      {
        materialId: supplier.materialId,
        materialName: supplier.materialName,
        productLink: supplier.productLink,
        note: supplier.note,
        referencePrice: supplier.referencePrice,
      },
    ]);
  }

  return [];
};

// -----------------------------------------------------------------------------
// Normalisasi satu record supplier dari collection master / schema lama.
// Hasil ini jadi format tunggal yang dipakai semua halaman.
// -----------------------------------------------------------------------------
export const normalizeSupplierRecord = (supplier = {}, sourceCollection = SUPPLIER_MASTER_COLLECTION) => {
  const materialDetails = normalizeMasterMaterialDetails(supplier);
  const supportedMaterialIds = uniqueStrings([
    ...(supplier.supportedMaterialIds || []),
    ...materialDetails.map((detail) => detail.materialId),
  ]);
  const supportedMaterialNames = uniqueStrings([
    ...(supplier.supportedMaterialNames || []),
    ...materialDetails.map((detail) => detail.materialName),
  ]);

  return {
    ...supplier,
    id: supplier.id,
    firestoreSupplierId: supplier.id,
    masterSupplierId: sourceCollection === SUPPLIER_MASTER_COLLECTION ? supplier.id : supplier.masterSupplierId || null,
    sourceCollection,
    isMasterRecord: sourceCollection === SUPPLIER_MASTER_COLLECTION,
    canRestore: sourceCollection !== SUPPLIER_MASTER_COLLECTION,
    storeName: getSupplierDisplayName(supplier),
    storeLink: getSupplierLink(supplier),
    category: getSupplierCategory(supplier),
    materialDetails,
    supportedMaterialIds,
    supportedMaterialNames,
    aliasNames: uniqueStrings([
      supplier.storeName,
      supplier.name,
      supplier.supplierName,
      supplier.title,
      supplier.item,
    ]),
  };
};

// -----------------------------------------------------------------------------
// Bangun supplier fallback dari data bahan baku lama.
// Ini menjaga menu Supplier tetap berisi walau master supplier sempat kosong.
// -----------------------------------------------------------------------------
const buildLegacySuppliersFromMaterials = (materials = []) => {
  const supplierMap = new Map();

  (materials || []).forEach((material = {}) => {
    const supplierName = safeTrim(material.supplierName || material.storeName || material.supplier || '');
    const supplierLink = safeTrim(material.supplierLink || material.storeLink || '');
    const supplierId = safeTrim(material.supplierId || '');

    if (!supplierName && !supplierLink && !supplierId) {
      return;
    }

    const materialId = safeTrim(material.id);
    const materialName = safeTrim(material.name || material.materialName || '');
    const materialDetail = {
      materialId,
      materialName,
      productLink: safeTrim(material.productLink || material.supplierProductLink || ''),
      note: 'Terdeteksi dari master bahan baku',
      referencePrice: Math.round(Number(material.restockReferencePrice || material.referencePrice || 0)),
    };

    const dedupeKey = [normalizeKey(supplierName), normalizeKey(supplierLink), normalizeKey(supplierId)]
      .filter(Boolean)
      .join('|') || `legacy-supplier-${supplierMap.size}`;

    const existingSupplier = supplierMap.get(dedupeKey);

    if (!existingSupplier) {
      supplierMap.set(dedupeKey, {
        id: supplierId || `legacy:${dedupeKey}`,
        firestoreSupplierId: null,
        masterSupplierId: null,
        sourceCollection: RAW_MATERIAL_COLLECTION,
        isMasterRecord: false,
        canRestore: true,
        storeName: supplierName || 'Supplier lama',
        storeLink: supplierLink,
        category: '',
        materialDetails: materialName || materialId ? [materialDetail] : [],
        supportedMaterialIds: materialId ? [materialId] : [],
        supportedMaterialNames: materialName ? [materialName] : [],
        aliasNames: uniqueStrings([supplierName]),
      });
      return;
    }

    existingSupplier.materialDetails = uniqueMaterialDetails([
      ...(existingSupplier.materialDetails || []),
      materialDetail,
    ]);
    existingSupplier.supportedMaterialIds = uniqueStrings([
      ...(existingSupplier.supportedMaterialIds || []),
      materialId,
    ]);
    existingSupplier.supportedMaterialNames = uniqueStrings([
      ...(existingSupplier.supportedMaterialNames || []),
      materialName,
    ]);
  });

  return Array.from(supplierMap.values());
};

// -----------------------------------------------------------------------------
// Nilai kelengkapan data supplier untuk menentukan record mana yang diprioritaskan.
// -----------------------------------------------------------------------------
const getSupplierCompletenessScore = (supplier = {}) => {
  let score = 0;

  if (supplier.sourceCollection === SUPPLIER_MASTER_COLLECTION) score += 200;
  if (supplier.sourceCollection === LEGACY_SUPPLIER_COLLECTION) score += 120;
  if (supplier.sourceCollection === RAW_MATERIAL_COLLECTION) score += 40;
  if (safeTrim(supplier.storeName)) score += 20;
  if (safeTrim(supplier.storeLink)) score += 10;
  if (safeTrim(supplier.category)) score += 5;
  score += Number(supplier.materialDetails?.length || 0);
  score += Number(supplier.supportedMaterialIds?.length || 0);

  return score;
};

// -----------------------------------------------------------------------------
// Dedupe key supplier lintas collection.
// Prioritas nama karena kasus user saat ini sering hanya punya supplierName.
// -----------------------------------------------------------------------------
const buildSupplierDedupeKey = (supplier = {}) => {
  const nameKey = normalizeKey(getSupplierDisplayName(supplier));
  const linkKey = normalizeKey(getSupplierLink(supplier));
  const sourceIdKey = normalizeKey(supplier.id);

  if (nameKey) return nameKey;
  if (linkKey) return linkKey;
  return `${supplier.sourceCollection || 'unknown'}:${sourceIdKey || 'no-id'}`;
};

// -----------------------------------------------------------------------------
// Merge dua record supplier agar material pendukung tidak hilang.
// -----------------------------------------------------------------------------
const mergeTwoSupplierRecords = (leftSupplier = {}, rightSupplier = {}) => {
  const preferredSupplier =
    getSupplierCompletenessScore(rightSupplier) > getSupplierCompletenessScore(leftSupplier)
      ? rightSupplier
      : leftSupplier;
  const secondarySupplier = preferredSupplier === leftSupplier ? rightSupplier : leftSupplier;

  const materialDetails = uniqueMaterialDetails([
    ...(leftSupplier.materialDetails || []),
    ...(rightSupplier.materialDetails || []),
  ]);

  return {
    ...secondarySupplier,
    ...preferredSupplier,
    isMasterRecord: preferredSupplier.sourceCollection === SUPPLIER_MASTER_COLLECTION,
    canRestore: preferredSupplier.sourceCollection !== SUPPLIER_MASTER_COLLECTION,
    masterSupplierId:
      preferredSupplier.sourceCollection === SUPPLIER_MASTER_COLLECTION
        ? preferredSupplier.id
        : preferredSupplier.masterSupplierId || secondarySupplier.masterSupplierId || null,
    storeName: getSupplierDisplayName(preferredSupplier) || getSupplierDisplayName(secondarySupplier),
    storeLink: getSupplierLink(preferredSupplier) || getSupplierLink(secondarySupplier),
    category: getSupplierCategory(preferredSupplier) || getSupplierCategory(secondarySupplier),
    materialDetails,
    supportedMaterialIds: uniqueStrings([
      ...(leftSupplier.supportedMaterialIds || []),
      ...(rightSupplier.supportedMaterialIds || []),
      ...materialDetails.map((detail) => detail.materialId),
    ]),
    supportedMaterialNames: uniqueStrings([
      ...(leftSupplier.supportedMaterialNames || []),
      ...(rightSupplier.supportedMaterialNames || []),
      ...materialDetails.map((detail) => detail.materialName),
    ]),
    aliasNames: uniqueStrings([
      ...(leftSupplier.aliasNames || []),
      ...(rightSupplier.aliasNames || []),
      getSupplierDisplayName(leftSupplier),
      getSupplierDisplayName(rightSupplier),
    ]),
  };
};

// -----------------------------------------------------------------------------
// Gabungkan snapshot supplier master lama/baru + fallback dari raw materials.
// -----------------------------------------------------------------------------
export const mergeSupplierSnapshots = ({ masterGroups = {}, rawMaterials = [] } = {}) => {
  const mergedSupplierMap = new Map();
  const masterSuppliers = Object.entries(masterGroups).flatMap(([sourceCollection, items]) =>
    (items || []).map((item) => normalizeSupplierRecord(item, sourceCollection)),
  );
  const legacySuppliers = buildLegacySuppliersFromMaterials(rawMaterials);

  [...masterSuppliers, ...legacySuppliers].forEach((supplier) => {
    const dedupeKey = buildSupplierDedupeKey(supplier);
    const existingSupplier = mergedSupplierMap.get(dedupeKey);

    if (!existingSupplier) {
      mergedSupplierMap.set(dedupeKey, supplier);
      return;
    }

    mergedSupplierMap.set(dedupeKey, mergeTwoSupplierRecords(existingSupplier, supplier));
  });

  return Array.from(mergedSupplierMap.values()).sort((leftSupplier, rightSupplier) =>
    getSupplierDisplayName(leftSupplier).localeCompare(getSupplierDisplayName(rightSupplier), 'id-ID'),
  );
};

// -----------------------------------------------------------------------------
// Builder options Select Ant Design untuk semua halaman yang butuh dropdown.
// -----------------------------------------------------------------------------
export const buildSupplierSelectOptions = (suppliers = []) => {
  return (suppliers || []).map((supplier) => ({
    value: supplier.id,
    label: getSupplierOptionLabel(supplier),
    supplier,
  }));
};

// -----------------------------------------------------------------------------
// Alias listener baru agar patch lama dan patch baru sama-sama aman.
// -----------------------------------------------------------------------------
export const listenSuppliers = (callback, onError) => {
  const supplierGroups = {};
  let rawMaterials = [];

  const emitSuppliers = () => {
    callback(
      mergeSupplierSnapshots({
        masterGroups: supplierGroups,
        rawMaterials,
      }),
    );
  };

  const masterUnsubscribers = SUPPLIER_MASTER_COLLECTIONS.map((collectionName) =>
    onSnapshot(
      collection(db, collectionName),
      (snapshot) => {
        supplierGroups[collectionName] = snapshot.docs.map((documentItem) => ({
          id: documentItem.id,
          ...documentItem.data(),
        }));
        emitSuppliers();
      },
      (error) => {
        console.error(`Gagal memuat collection supplier: ${collectionName}`, error);
        if (typeof onError === 'function') {
          onError(error, collectionName);
        }
      },
    ),
  );

  const rawMaterialUnsubscriber = onSnapshot(
    collection(db, RAW_MATERIAL_COLLECTION),
    (snapshot) => {
      rawMaterials = snapshot.docs.map((documentItem) => ({
        id: documentItem.id,
        ...documentItem.data(),
      }));
      emitSuppliers();
    },
    (error) => {
      console.error('Gagal memuat raw materials untuk fallback supplier.', error);
      if (typeof onError === 'function') {
        onError(error, RAW_MATERIAL_COLLECTION);
      }
    },
  );

  return () => {
    masterUnsubscribers.forEach((unsubscribe) => unsubscribe());
    rawMaterialUnsubscriber();
  };
};

// -----------------------------------------------------------------------------
// Alias nama listener dari patch relink sebelumnya.
// -----------------------------------------------------------------------------
export const listenSupplierCatalog = listenSuppliers;

// -----------------------------------------------------------------------------
// Build payload supplier master yang rapi saat restore / edit supplier.
// -----------------------------------------------------------------------------
const buildMasterSupplierPayload = (supplier = {}) => {
  const materialDetails = uniqueMaterialDetails(supplier.materialDetails || []).map((item) => ({
    materialId: item.materialId || '',
    materialName: item.materialName || '',
    productLink: item.productLink || '',
    referencePrice: Math.round(Number(item.referencePrice || 0)),
    note: item.note || '',
  }));

  return {
    category: supplier.category || '',
    storeName: getSupplierDisplayName(supplier),
    storeLink: getSupplierLink(supplier),
    supportedMaterialIds: uniqueStrings([
      ...(supplier.supportedMaterialIds || []),
      ...materialDetails.map((item) => item.materialId),
    ]),
    supportedMaterialNames: uniqueStrings([
      ...(supplier.supportedMaterialNames || []),
      ...materialDetails.map((item) => item.materialName),
    ]),
    materialDetails,
    updatedAt: serverTimestamp(),
  };
};

// -----------------------------------------------------------------------------
// Cari master supplier yang cocok berdasarkan nama atau link.
// Ini mencegah restore ganda saat supplier lama sudah pernah dipulihkan.
// -----------------------------------------------------------------------------
const findMatchingMasterSupplier = (masterSuppliers = [], supplier = {}) => {
  const normalizedName = normalizeKey(getSupplierDisplayName(supplier));
  const normalizedLink = normalizeKey(getSupplierLink(supplier));

  return masterSuppliers.find((item) => {
    const itemName = normalizeKey(getSupplierDisplayName(item));
    const itemLink = normalizeKey(getSupplierLink(item));

    if (normalizedName && itemName === normalizedName) return true;
    if (normalizedLink && itemLink && itemLink === normalizedLink) return true;
    return false;
  });
};

// -----------------------------------------------------------------------------
// Pulihkan supplier lama ke collection master baru.
// Jika supplier master sudah ada, data master diperkaya lalu dipakai ulang.
// -----------------------------------------------------------------------------
export const restoreLegacySupplierToMaster = async (supplier = {}) => {
  const masterSnapshot = await getDocs(collection(db, SUPPLIER_MASTER_COLLECTION));
  const masterSuppliers = masterSnapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

  const existingMaster =
    (supplier.masterSupplierId
      ? masterSuppliers.find((item) => item.id === supplier.masterSupplierId)
      : null) || findMatchingMasterSupplier(masterSuppliers, supplier);

  const payload = buildMasterSupplierPayload(supplier);

  if (existingMaster) {
    const mergedPayload = {
      ...payload,
      category: payload.category || existingMaster.category || '',
      storeLink: payload.storeLink || existingMaster.storeLink || '',
      supportedMaterialIds: uniqueStrings([
        ...(existingMaster.supportedMaterialIds || []),
        ...(payload.supportedMaterialIds || []),
      ]),
      supportedMaterialNames: uniqueStrings([
        ...(existingMaster.supportedMaterialNames || []),
        ...(payload.supportedMaterialNames || []),
      ]),
      materialDetails: uniqueMaterialDetails([
        ...(existingMaster.materialDetails || []),
        ...(payload.materialDetails || []),
      ]),
    };

    await updateDoc(doc(db, SUPPLIER_MASTER_COLLECTION, existingMaster.id), mergedPayload);
    return { supplierId: existingMaster.id, isCreated: false };
  }

  const createdDoc = await addDoc(collection(db, SUPPLIER_MASTER_COLLECTION), {
    ...payload,
    createdAt: serverTimestamp(),
  });

  return { supplierId: createdDoc.id, isCreated: true };
};

// -----------------------------------------------------------------------------
// Relink semua bahan baku yang cocok ke master supplier baru.
// Ini yang membuat detail bahan baku otomatis tersambung lagi.
// -----------------------------------------------------------------------------
export const relinkRawMaterialsToSupplier = async (supplier = {}, masterSupplierId) => {
  if (!masterSupplierId) {
    return { updatedCount: 0 };
  }

  const rawMaterialsSnapshot = await getDocs(collection(db, RAW_MATERIAL_COLLECTION));
  const rawMaterials = rawMaterialsSnapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

  const normalizedSupplierNames = uniqueStrings([
    getSupplierDisplayName(supplier),
    ...(supplier.aliasNames || []),
  ]).map((item) => normalizeKey(item));

  const targetMaterialIds = new Set(
    uniqueStrings([
      ...(supplier.supportedMaterialIds || []),
      ...((supplier.materialDetails || []).map((item) => item.materialId)),
    ]),
  );

  const matchedMaterials = rawMaterials.filter((material) => {
    const materialSupplierName = normalizeKey(material.supplierName || '');
    const materialSupplierId = safeTrim(material.supplierId || '');

    if (targetMaterialIds.has(material.id)) return true;
    if (materialSupplierId && materialSupplierId === masterSupplierId) return true;
    if (materialSupplierName && normalizedSupplierNames.includes(materialSupplierName)) return true;
    return false;
  });

  if (matchedMaterials.length === 0) {
    return { updatedCount: 0 };
  }

  const batch = writeBatch(db);

  matchedMaterials.forEach((material) => {
    batch.update(doc(db, RAW_MATERIAL_COLLECTION, material.id), {
      supplierId: masterSupplierId,
      supplierName: getSupplierDisplayName(supplier) || material.supplierName || '',
      supplierLink: getSupplierLink(supplier) || material.supplierLink || '',
      updatedAt: serverTimestamp(),
    });
  });

  await batch.commit();
  return { updatedCount: matchedMaterials.length };
};

// -----------------------------------------------------------------------------
// 1 aksi lengkap: pulihkan supplier lama lalu sambungkan ulang bahan bakunya.
// -----------------------------------------------------------------------------
export const restoreAndRelinkSupplier = async (supplier = {}) => {
  const restoreResult = await restoreLegacySupplierToMaster(supplier);
  const relinkResult = await relinkRawMaterialsToSupplier(supplier, restoreResult.supplierId);

  return {
    supplierId: restoreResult.supplierId,
    isCreated: restoreResult.isCreated,
    updatedCount: relinkResult.updatedCount,
  };
};

// -----------------------------------------------------------------------------
// Migrasi massal supplier lama sekali jalan.
// -----------------------------------------------------------------------------
export const bulkRestoreAndRelinkLegacySuppliers = async (suppliers = []) => {
  const candidates = (suppliers || []).filter((item) => isLegacyMaterialSupplierRecord(item));

  let restoredCount = 0;
  let relinkedMaterialsCount = 0;

  for (const supplier of candidates) {
    const result = await restoreAndRelinkSupplier(supplier);
    restoredCount += 1;
    relinkedMaterialsCount += Number(result.updatedCount || 0);
  }

  return {
    restoredCount,
    relinkedMaterialsCount,
  };
};
