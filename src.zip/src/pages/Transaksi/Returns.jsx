import React, { useEffect, useMemo, useState } from "react";
import {
  Table,
  Modal,
  Form,
  Select,
  InputNumber,
  DatePicker,
  Input,
  message,
  Tag,
  Tooltip,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { collection, doc, onSnapshot, runTransaction, Timestamp } from "firebase/firestore";
import dayjs from "dayjs";
import { db } from "../../firebase";
import PageHeader from "../../components/Layout/Page/PageHeader";
import PageSection from "../../components/Layout/Page/PageSection";
import { DataRefreshIndicator, getDataTableEmptyText } from "../../components/Layout/Feedback/DataLoadingState";
import {
  buildInventoryLogPayload,
  INVENTORY_LOG_COLLECTION,
} from "../../services/Inventory/inventoryLogService";
import {
  applyStockMutationToItem,
  buildVariantOptionsFromItem,
  findVariantByKey,
  getItemStockSnapshot,
  inferHasVariants,
} from "../../utils/variants/variantStockHelpers";
import { formatNumberId, parseIntegerIdInput } from "../../utils/formatters/numberId";
import { generateDailySequenceCode } from "../../utils/references/businessCodeGenerator";
import { showFormValidationFeedback } from '../../utils/forms/formValidationFeedback';


// IMS NOTE [AKTIF/GUARDED] - Standar input angka bulat
// Fungsi blok: mengarahkan InputNumber aktif ke step 1, precision 0, dan parser integer Indonesia.
// Hubungan flow: hanya membatasi input/display UI; service calculation stok, kas, HPP, payroll, dan report tidak diubah.
// Alasan logic: IMS operasional memakai angka tanpa desimal, sementara data lama decimal tidak dimigrasi otomatis.
// Behavior: input baru no-decimal; business rules dan schema Firestore tetap sama.

const { Option } = Select;

// =========================
// SECTION: Returns Page
// =========================
const Returns = () => {
  const [form] = Form.useForm();

  // =========================
  // SECTION: State utama
  // =========================
  const [returnRecords, setReturnRecords] = useState([]);
  const [products, setProducts] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItemType, setSelectedItemType] = useState("product");

  // =========================
  // SECTION: Submit loading guard
  // AKTIF + GUARDED:
  // - mencegah user menekan Simpan Retur berkali-kali saat transaction masih berjalan;
  // - menjaga satu klik submit tidak membuat double stock atau double inventory log.
  // =========================
  const [isSubmittingReturn, setIsSubmittingReturn] = useState(false);

  const selectedItemId = Form.useWatch("itemId", form);
  const selectedVariantKey = Form.useWatch("variantKey", form);

  // =========================
  // SECTION: Semua item
  // =========================
  const allItems = useMemo(() => {
    return [...products, ...materials];
  }, [products, materials]);

  const selectedItemsByType = selectedItemType === "product" ? products : materials;
  const selectedItem = useMemo(
    () => selectedItemsByType.find((item) => item.id === selectedItemId) || null,
    [selectedItemId, selectedItemsByType],
  );
  const selectedItemHasVariants = inferHasVariants(selectedItem || {});
  const variantOptions = useMemo(
    () => (selectedItemHasVariants ? buildVariantOptionsFromItem(selectedItem) : []),
    [selectedItem, selectedItemHasVariants],
  );
  const selectedVariant = useMemo(
    () => (selectedItemHasVariants ? findVariantByKey(selectedItem, selectedVariantKey) : null),
    [selectedItem, selectedItemHasVariants, selectedVariantKey],
  );

  // =========================
  // SECTION: Live Data Subscription
  // =========================
  useEffect(() => {
    const unsubscribeReturns = onSnapshot(
      collection(db, "returns"),
      (snapshot) => {
        const nextReturnRecords = snapshot.docs.map((documentItem) => ({
          id: documentItem.id,
          ...documentItem.data(),
        }));

        setReturnRecords(nextReturnRecords);
        setLoadError("");
        setIsLoading(false);
      },
      (error) => {
        console.error("Gagal memuat data retur:", error);
        setReturnRecords([]);
        setLoadError("Gagal memuat data retur.");
        setIsLoading(false);
        message.error("Gagal memuat data retur.");
      },
    );

    const unsubscribeProducts = onSnapshot(
      collection(db, "products"),
      (snapshot) => {
        const nextProducts = snapshot.docs.map((documentItem) => ({
          id: documentItem.id,
          ...documentItem.data(),
        }));

        setProducts(nextProducts);
      },
      (error) => {
        console.error("Gagal memuat produk untuk retur:", error);
        message.error("Gagal memuat produk untuk retur.");
      },
    );

    const unsubscribeMaterials = onSnapshot(
      collection(db, "raw_materials"),
      (snapshot) => {
        const nextMaterials = snapshot.docs.map((documentItem) => ({
          id: documentItem.id,
          ...documentItem.data(),
        }));

        setMaterials(nextMaterials);
      },
      (error) => {
        console.error("Gagal memuat bahan baku untuk retur:", error);
        message.error("Gagal memuat bahan baku untuk retur.");
      },
    );

    return () => {
      unsubscribeReturns();
      unsubscribeProducts();
      unsubscribeMaterials();
    };
  }, []);

  useEffect(() => {
    form.setFieldsValue({ itemId: undefined, variantKey: undefined });
  }, [form, selectedItemType]);

  useEffect(() => {
    form.setFieldsValue({ variantKey: undefined });
  }, [form, selectedItemId]);

  // =========================
  // SECTION: Modal Helpers
  // =========================
  const resetReturnFormState = () => {
    form.resetFields();
    setIsModalOpen(false);
    setSelectedItemType("product");
  };

  const openCreateReturnModal = () => {
    form.resetFields();
    form.setFieldsValue({ date: dayjs(), type: "product" });
    setSelectedItemType("product");
    setIsModalOpen(true);
  };

  // =========================
  // SECTION: Submit Return
  // AKTIF + GUARDED:
  // - flow ini adalah jalur resmi retur yang menambah stok kembali;
  // - dokumen retur, update stok, dan inventory log wajib commit bersama dalam Firestore transaction;
  // - tidak memakai addInventoryLog/updateInventoryStock langsung agar tidak ada stok berubah tanpa audit log.
  // LEGACY:
  // - flow lama melakukan update stok lebih dulu, lalu addDoc returns, lalu addInventoryLog; jika addDoc/log gagal, stok bisa sudah berubah.
  // CLEANUP CANDIDATE:
  // - jika nanti ada service khusus retur, orkestrasi transaction ini bisa dipindah dari page ke service tanpa mengubah business rule.
  // =========================
  const handleSubmitReturn = async (values) => {
    if (isSubmittingReturn) return;

    setIsSubmittingReturn(true);

    try {
      const { type, itemId, quantity, date, note, variantKey } = values;
      const collectionName = type === "product" ? "products" : "raw_materials";
      const normalizedQuantity = Number(quantity || 0);
      const normalizedNote = String(note || "").trim();

      // =========================
      // SECTION: Validasi awal sebelum write pertama
      // AKTIF + GUARDED:
      // - memastikan data wajib valid sebelum Firestore transaction dibuat;
      // - menjaga retur tidak menghasilkan dokumen/log/stok dengan item, tanggal, atau qty kosong;
      // - validasi ini tidak mengubah business rule retur, hanya mencegah partial write dan data rusak.
      // =========================
      if (!type || !["product", "material"].includes(type)) {
        message.error("Jenis item retur tidak valid.");
        return;
      }

      if (!itemId) {
        message.error("Item retur wajib dipilih.");
        return;
      }

      if (!Number.isFinite(normalizedQuantity) || normalizedQuantity <= 0) {
        message.error("Jumlah retur harus lebih dari 0.");
        return;
      }

      if (!date?.toDate || !dayjs(date.toDate()).isValid()) {
        message.error("Tanggal retur tidak valid.");
        return;
      }

      const item = allItems.find((sourceItem) => sourceItem.id === itemId);

      if (!item) {
        message.error("Item tidak ditemukan");
        return;
      }

      if (inferHasVariants(item) && !variantKey) {
        message.error("Pilih varian item terlebih dahulu agar retur masuk ke stok varian yang benar.");
        return;
      }

      const returnTimestamp = Timestamp.fromDate(date.toDate());
      const returnNumber = await generateDailySequenceCode({
        db,
        collectionName: "returns",
        fieldNames: ["returnNumber", "code", "referenceNumber", "sourceRef"],
        prefix: "RET",
        date: date.toDate(),
      });
      /* =====================================================
      SECTION: Return reference document ID — GUARDED
      Fungsi:
      - Membuat document reference return baru memakai RET-DDMMYYYY-001 sebagai ID.

      Dipakai oleh:
      - handleSubmitReturn sebelum transaction retur.

      Alasan perubahan:
      - Return baru perlu reference audit yang sama antara document ID, returnNumber, dan inventory log.

      Catatan cleanup:
      - Data retur lama dengan random ID tetap compatibility.

      Risiko:
      - Jangan mengubah return stock mutation atau inventory log payload selain reference code.
      ===================================================== */
      const returnReference = doc(db, "returns", returnNumber);
      const itemReference = doc(db, collectionName, itemId);
      const inventoryLogReference = doc(collection(db, INVENTORY_LOG_COLLECTION));

      await runTransaction(db, async (transaction) => {
        const returnSnapshot = await transaction.get(returnReference);
        const itemDocument = await transaction.get(itemReference);

        // IMS NOTE [GUARDED] - collision guard kode RET scan-based.
        // Fungsi: mencegah transaction retur menimpa dokumen lama jika nomor bisnis sudah dipakai.
        if (returnSnapshot.exists()) {
          throw new Error(`Nomor retur ${returnNumber} sudah dipakai. Muat ulang data lalu simpan kembali.`);
        }

        if (!itemDocument.exists()) {
          throw new Error("Item stok tidak ditemukan. Retur dibatalkan agar stok dan log tidak partial.");
        }

        const latestItem = {
          id: itemDocument.id,
          ...itemDocument.data(),
        };
        const latestItemName = latestItem?.name || item?.name || "Item tanpa nama";
        const latestItemHasVariants = inferHasVariants(latestItem);
        const selectedVariant = latestItemHasVariants
          ? findVariantByKey(latestItem, variantKey)
          : null;

        // =========================
        // SECTION: Validasi ulang varian di dalam transaction
        // AKTIF + GUARDED:
        // - membaca item terbaru dari Firestore, bukan hanya state UI;
        // - mencegah retur masuk ke master/default ketika item sebenarnya bervarian;
        // - menjaga stock/currentStock/availableStock varian tetap sinkron lewat helper final.
        // =========================
        if (latestItemHasVariants && !variantKey) {
          throw new Error("Item memiliki varian. Pilih varian agar stok retur masuk ke sumber yang benar.");
        }

        if (latestItemHasVariants && !selectedVariant) {
          throw new Error("Varian item tidak ditemukan. Retur dibatalkan agar stok tidak masuk ke master/default.");
        }

        const stockSnapshotBefore = selectedVariant
          ? getItemStockSnapshot(selectedVariant)
          : getItemStockSnapshot(latestItem);
        const stockUpdatePayload = applyStockMutationToItem({
          item: latestItem,
          variantKey: selectedVariant?.variantKey || "",
          deltaCurrent: normalizedQuantity,
        });
        const currentStockAfter = stockSnapshotBefore.currentStock + normalizedQuantity;
        const availableStockAfter = currentStockAfter - stockSnapshotBefore.reservedStock;
        const variantPayload = {
          variantKey: selectedVariant?.variantKey || "",
          variantLabel: selectedVariant?.variantLabel || "",
          stockSourceType: selectedVariant ? "variant" : "master",
        };
        const stockUnit =
          latestItem.stockUnit ||
          latestItem.unit ||
          latestItem.baseUnit ||
          (collectionName === "products" ? "pcs" : "");

        // =========================
        // SECTION: Commit atomik retur + stok + inventory log
        // AKTIF + GUARDED:
        // - ketiga write ini berada dalam satu Firestore transaction;
        // - jika salah satu gagal, tidak ada stok berubah tanpa dokumen retur/log;
        // - inventory log memakai buildInventoryLogPayload agar schema audit sama dengan writer aktif lain.
        // =========================
        transaction.set(returnReference, {
          returnNumber,
          code: returnNumber,
          referenceNumber: returnNumber,
          sourceRef: returnNumber,
          type,
          itemId,
          itemName: latestItemName,
          quantity: normalizedQuantity,
          unit: stockUnit,
          stockUnit,
          note: normalizedNote,
          date: returnTimestamp,
          ...variantPayload,
        });

        transaction.update(itemReference, stockUpdatePayload);

        transaction.set(
          inventoryLogReference,
          buildInventoryLogPayload({
            itemId,
            itemName: latestItemName,
            quantityChange: normalizedQuantity,
            type: "return_in",
            collectionName,
            timestamp: Timestamp.now(),
            extraData: {
              returnId: returnReference.id,
              returnNumber,
              referenceId: returnReference.id,
              referenceNumber: returnNumber,
              referenceCode: returnNumber,
              referenceType: "return",
              unit: stockUnit,
              stockUnit,
              note: normalizedNote,
              currentStockBefore: stockSnapshotBefore.currentStock,
              currentStockAfter,
              previousStock: stockSnapshotBefore.currentStock,
              newStock: currentStockAfter,
              reservedStockBefore: stockSnapshotBefore.reservedStock,
              reservedStockAfter: stockSnapshotBefore.reservedStock,
              availableStockBefore: stockSnapshotBefore.availableStock,
              availableStockAfter,
              ...variantPayload,
            },
          }),
        );
      });

      message.success("Retur berhasil ditambahkan!");
      resetReturnFormState();
    } catch (error) {
      console.error(error);
      message.error(error?.message || "Gagal menyimpan retur");
    } finally {
      setIsSubmittingReturn(false);
    }
  };

  // =========================
  // SECTION: Table Columns
  // =========================
  /* =====================================================
     SECTION: Compact Returns Table Columns — AKTIF/GUARDED
     Fungsi:
     - Menampilkan ringkasan retur tanpa horizontal scroll besar.
     Dipakai oleh:
     - Returns main table.
     Alasan perubahan:
     - Tanggal, item/asal, qty retur, dan catatan harus terbaca langsung tanpa mengubah flow stok retur.
     Catatan cleanup:
     - Detail retur bisa dibuat drawer khusus jika audit retur bertambah kompleks.
     Risiko:
     - Jangan mengubah transaction retur, stock-in return, source relation, atau inventory log dari render kolom ini.
     ===================================================== */
  const returnTableColumns = [
    {
      title: "Tanggal / Ref",
      key: "dateReference",
      width: 170,
      render: (_, record) => {
        const dateText = record.date?.toDate ? dayjs(record.date.toDate()).format("DD-MM-YYYY HH:mm") : "-";
        const referenceText = record.returnNumber || record.code || record.referenceNumber || record.referenceId || record.returnId || record.id || "-";
        return (
          <div style={{ minWidth: 0 }}>
            <div className="ims-cell-title">{dateText}</div>
            <Tooltip title={referenceText}>
              <div className="ims-cell-meta" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {referenceText}
              </div>
            </Tooltip>
          </div>
        );
      },
    },
    {
      title: "Item / Asal",
      key: "itemSource",
      width: 270,
      render: (_, record) => {
        const itemName = record.itemName || "-";
        const typeTag = record.type === "product" ? <Tag color="blue">Produk</Tag> : <Tag color="gold">Bahan Baku</Tag>;
        const variantTag = record.variantLabel || record.variantKey ? (
          <Tag color="purple">{record.variantLabel || record.variantKey}</Tag>
        ) : (
          <Tag>Master</Tag>
        );

        return (
          <div style={{ minWidth: 0 }}>
            <Tooltip title={itemName}>
              <div className="ims-cell-title" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {itemName}
              </div>
            </Tooltip>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 4 }}>
              {typeTag}
              {variantTag}
            </div>
          </div>
        );
      },
    },
    {
      title: "Qty Return",
      dataIndex: "quantity",
      key: "quantity",
      width: 130,
      align: "right",
      render: (value, record) => {
        const unit = record.stockUnit || record.unit || "";
        return <strong>{formatNumberId(value)}{unit ? ` ${unit}` : ""}</strong>;
      },
    },
    {
      title: "Alasan / Catatan",
      dataIndex: "note",
      key: "note",
      width: 280,
      render: (value) => {
        const noteText = value || "-";
        return (
          <Tooltip title={noteText}>
            <span style={{ display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {noteText}
            </span>
          </Tooltip>
        );
      },
    },
  ];

  /* =====================================================
     SECTION: Returns Render Panel — GUARDED
     Fungsi:
     - Menata tabel dan form retur agar tipe item, varian, qty, alasan, dan dampak stok tetap jelas.

     Dipakai oleh:
     - Halaman Returns.

     Alasan perubahan:
     - Batch 3 merapikan microcopy retur tanpa mengubah stock mutation, reference relation, refund/cash logic, atau payload submit.

     Catatan cleanup:
     - Detail retur bisa dibuat drawer audit jika relasi sales/purchase makin kompleks.

     Risiko:
     - Jangan mengubah logic stok kembali, relation transaksi, inventory log, atau validation dari section ini.
     ===================================================== */
  return (
    <>
      <PageHeader
        title="Retur"
        subtitle="Retur dan stok kembali."
        actions={[
          {
            key: "add-return",
            type: "primary",
            icon: <PlusOutlined />,
            label: "Tambah Retur",
            onClick: openCreateReturnModal,
          },
        ]}
      />

      <PageSection
        title="Data Retur"
        subtitle="Stok kembali sesuai item/varian."
      >
        {/* =========================
            SECTION: tabel retur baseline global
            Fungsi:
            - retur tidak punya detail drawer, jadi tabel ringkas fokus ke data inti tanpa aksi tambahan
            - kolom varian memakai schema final dari record retur/log
            Status: aktif / final
        ========================= */}
        <DataRefreshIndicator loading={isLoading} dataSource={returnRecords} />
        <Table
          className="app-data-table"
          dataSource={returnRecords}
          columns={returnTableColumns}
          rowKey="id"
          tableLayout="fixed"
          locale={{ emptyText: getDataTableEmptyText(isLoading, loadError || "Belum ada data retur.") }}
        />
      </PageSection>

      <Modal
        title="Tambah Retur"
        open={isModalOpen}
        onOk={form.submit}
        onCancel={resetReturnFormState}
        confirmLoading={isSubmittingReturn}
        okText="Simpan"
        cancelText="Batal"
        width={720}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmitReturn}
          onFinishFailed={(errorInfo) => showFormValidationFeedback(errorInfo, { form })}
        >
          <Form.Item
            name="date"
            label="Tanggal"
            rules={[{ required: true, message: "Tanggal wajib diisi" }]}
          >
            <DatePicker style={{ width: "100%" }} />
          </Form.Item>

          <Form.Item
            name="type"
            label="Jenis Item"
            rules={[{ required: true, message: "Jenis wajib dipilih" }]}
          >
            <Select
              placeholder="Pilih jenis item"
              onChange={(value) => setSelectedItemType(value)}
            >
              <Option value="product">Produk</Option>
              <Option value="material">Bahan Baku</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="itemId"
            label="Nama Item"
            rules={[{ required: true, message: "Item wajib dipilih" }]}
          >
            <Select placeholder="Pilih item" showSearch optionFilterProp="children">
              {selectedItemType === "product"
                ? products.map((item) => (
                    <Option key={item.id} value={item.id}>
                      {item.name}
                    </Option>
                  ))
                : materials.map((item) => (
                    <Option key={item.id} value={item.id}>
                      {item.name}
                    </Option>
                  ))}
            </Select>
          </Form.Item>

          {selectedItemHasVariants ? (
            <Form.Item
              name="variantKey"
              label={selectedItem?.variantLabel || "Varian"}
              rules={[{ required: true, message: "Varian wajib dipilih" }]}
              extra="Item bervarian wajib pilih varian."
            >
              <Select placeholder="Pilih varian" showSearch optionFilterProp="children">
                {variantOptions.map((item) => (
                  <Option key={item.value} value={item.value}>
                    {item.label} - Stok: {formatNumberId(item.raw?.currentStock || 0)}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          ) : null}

          {selectedItem ? (
            /* IMS NOTE [AKTIF/GUARDED] - Snapshot stok Returns.
               Fungsi blok: menampilkan stok current/reserved/available item retur sebagai panel read-only pasif.
               Hubungan flow: hanya mengganti tampilan Alert lama; transaction retur, stock revert, inventory log, validasi, dan payload Firestore tidak berubah.
               Alasan logic: stok sebelum retur adalah info kontekstual, bukan warning/error, sehingga mengikuti panel clean seperti Purchases/Stock Adjustment.
               Status: AKTIF untuk UI Returns, GUARDED terhadap business rule retur dan stok. */
            <div className="ims-readonly-panel">
              <div className="ims-readonly-panel-header">
                <div>
                  <div className="ims-readonly-panel-title">
                    Stok Item Sebelum Retur
                  </div>
                  <div className="ims-readonly-panel-description">
                    Info stok sebelum retur disimpan.
                  </div>
                </div>
                <Tag color={selectedItemHasVariants ? "purple" : "default"}>
                  {selectedItemHasVariants ? "Varian" : "Master"}
                </Tag>
              </div>

              <div style={{ marginBottom: 10 }}>
                <span className="ims-cell-title">
                  {selectedItem.name || "Item"}
                </span>
                {selectedItemHasVariants ? (
                  <span style={{ color: "var(--ims-text-secondary)" }}>
                    {` — ${selectedVariant?.variantLabel || selectedVariant?.name || "Pilih varian"}`}
                  </span>
                ) : null}
              </div>

              <div className="ims-readonly-stat-grid">
                <div className="ims-readonly-stat-field">
                  <div className="ims-readonly-stat-label">Stok Saat Ini</div>
                  <div className="ims-readonly-stat-value">
                    {formatNumberId((selectedItemHasVariants ? selectedVariant?.currentStock : getItemStockSnapshot(selectedItem).currentStock) || 0)}
                  </div>
                </div>
                <div className="ims-readonly-stat-field">
                  <div className="ims-readonly-stat-label">Stok Tertahan</div>
                  <div className="ims-readonly-stat-value">
                    {formatNumberId((selectedItemHasVariants ? selectedVariant?.reservedStock : getItemStockSnapshot(selectedItem).reservedStock) || 0)}
                  </div>
                </div>
                <div className="ims-readonly-stat-field">
                  <div className="ims-readonly-stat-label">Stok Tersedia</div>
                  <div className="ims-readonly-stat-value">
                    {formatNumberId((selectedItemHasVariants ? selectedVariant?.availableStock : getItemStockSnapshot(selectedItem).availableStock) || 0)}
                  </div>
                </div>
              </div>

              {selectedItemHasVariants ? (
                <div className="ims-readonly-panel-note">
                  Item bervarian wajib memilih varian agar retur masuk ke varian yang benar.
                </div>
              ) : null}
            </div>
          ) : null}

          <Form.Item
            name="quantity"
            label="Jumlah"
            rules={[{ required: true, message: "Jumlah wajib diisi" }]}
          >
            <InputNumber min={1} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
          </Form.Item>

          <Form.Item name="note" label="Catatan">
            <Input.TextArea rows={2} />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default Returns;
