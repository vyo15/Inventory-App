// =====================================================
// Page: Production Orders
// Support:
// - targetType = semi_finished_material
// - targetType = product
// Fungsi:
// - planning produksi
// - shortage check
// - flow aktif: BOM -> PO -> Mulai Produksi -> Work Log -> Complete
// - reserve/release lama dipensiunkan dari UI utama
// =====================================================

import React, { useEffect, useMemo, useState } from "react";
import dayjs from "dayjs";
import {
  Alert,
  Badge,
  Button,
  Card,
  Col,
  Descriptions,
  Divider,
  Drawer,
  Empty,
  Form,
  Input,
  InputNumber,
  message,
  Row,
  Select,
  Space,
  Statistic,
  Table,
  Tag,
  Typography,
} from "antd";
import { EyeOutlined, PlusOutlined } from "@ant-design/icons";
import { toReferenceOptions } from "../../utils/produksi/productionReferenceHelpers";
import {
  buildCountSummary,
  createKeywordMatcher,
  matchFieldValue,
} from "../../utils/produksi/productionPageHelpers";
import ProductionFilterCard from "../../components/Produksi/shared/ProductionFilterCard";
import ProductionPageHeader from "../../components/Produksi/shared/ProductionPageHeader";
import PageSection from "../../components/Layout/Page/PageSection";
import ProductionSummaryCards from "../../components/Produksi/shared/ProductionSummaryCards";
import formatNumber, { parseIntegerIdInput } from "../../utils/formatters/numberId";
import {
  buildProductionOrderRequirementLines,
  createProductionOrder,
  generateProductionOrderCode,
  getActiveProductionBomOptions,
  getAllProductionOrders,
  getProductionOrderTargetVariantOptions,
  refreshProductionOrderRequirements,
} from "../../services/Produksi/productionOrdersService";
import { createProductionWorkLogFromOrder } from "../../services/Produksi/productionWorkLogsService";
import useAuth from "../../hooks/useAuth";
import { DataRefreshIndicator, getDataTableEmptyText } from "../../components/Layout/Feedback/DataLoadingState";
import { buildDisplayReferenceSearchText, resolveDisplayReference } from "../../utils/references/displayReferenceResolver";

// IMS NOTE [AKTIF/GUARDED] - Standar input angka bulat
// Fungsi blok: mengarahkan InputNumber aktif ke step 1, precision 0, dan parser integer Indonesia.
// Hubungan flow: hanya membatasi input/display UI; service calculation stok, kas, HPP, payroll, dan report tidak diubah.
// Alasan logic: IMS operasional memakai angka tanpa desimal, sementara data lama decimal tidak dimigrasi otomatis.
// Behavior: input baru no-decimal; business rules dan schema Firestore tetap sama.

const PRODUCTION_ORDER_TARGET_TYPES = [
  {
    value: "semi_finished_material",
    label: "Semi Finished",
  },
  {
    value: "product",
    label: "Product",
  },
];

const PRIORITY_OPTIONS = [
  { value: "low", label: "Low" },
  { value: "normal", label: "Normal" },
  { value: "high", label: "High" },
  { value: "urgent", label: "Urgent" },
];

const ORDER_STATUS_MAP = {
  draft: { text: "Draft", status: "default" },
  shortage: { text: "Shortage", status: "error" },
  ready: { text: "Ready", status: "processing" },
  in_production: { text: "In Production", status: "processing" },
  completed: { text: "Completed", status: "success" },
  released: { text: "Released", status: "warning" },
  cancelled: { text: "Cancelled", status: "default" },
};

const PRIORITY_META_MAP = {
  low: { label: "Low", color: "default" },
  normal: { label: "Normal", color: "blue" },
  high: { label: "High", color: "orange" },
  urgent: { label: "Urgent", color: "red" },
};

// =====================================================
// Helper UI order
// Catatan maintainability:
// - Priority sengaja dipertahankan karena akan dipakai untuk scheduling.
// - Format tanggal dipusatkan di helper agar list dan drawer konsisten.
// =====================================================
const getPriorityMeta = (value) =>
  PRIORITY_META_MAP[value] || {
    label: value ? String(value) : "-",
    color: "default",
  };

const formatDateTimeLabel = (value) => {
  if (!value) return "-";
  const parsed = dayjs(value?.toDate?.() || value);
  return parsed.isValid() ? parsed.format("DD/MM/YYYY HH:mm") : "-";
};

// =====================================================
// Helper tampilan batch 1.
// Dipakai agar metadata baris, tag status, dan action button mengikuti fondasi
// tabel global tanpa mengulang inline style di setiap render kolom.
// =====================================================
const orderUiClassNames = {
  stack: "ims-cell-stack ims-cell-stack-tight",
  meta: "ims-cell-meta",
  title: "ims-cell-title",
};

const renderOrderCellBlock = (primary, secondaryLines = []) => (
  <div className={orderUiClassNames.stack}>
    <div className={orderUiClassNames.title}>{primary || "-"}</div>
    {secondaryLines.filter(Boolean).map((line, index) => (
      <div key={index} className={orderUiClassNames.meta}>{line}</div>
    ))}
  </div>
);

// =====================================================
// ACTIVE / FINAL - helper teks preview compact Buat PO.
// Fungsi:
// - menyamakan format qty + satuan pada target produksi dan material;
// - menjaga preview tetap ringkas tanpa tabel besar.
// Alasan perubahan:
// - drawer Buat PO harus lebih kecil dan hanya menampilkan info penting.
// Status:
// - aktif dipakai untuk UI read-only preview;
// - kandidat cleanup jika nanti dibuat komponen shared requirement preview.
// =====================================================
const formatQtyWithUnit = (value, unit = "") => {
  const normalizedUnit = String(unit || "").trim();
  return `${formatNumber(Number(value || 0))}${normalizedUnit ? ` ${normalizedUnit}` : ""}`;
};

const normalizeRequirementVariantStrategy = (line = {}) => {
  const rawStrategy = String(line.materialVariantStrategy || "none").trim().toLowerCase();
  return ["inherit", "fixed", "none"].includes(rawStrategy) ? rawStrategy : "none";
};

const lineRequiresVariantStock = (line = {}) => {
  const strategy = normalizeRequirementVariantStrategy(line);
  return line.materialHasVariants === true && strategy !== "none";
};

// =====================================================
// SECTION: Label sumber stok requirement PO.
// Fungsi blok:
// - membedakan material yang benar-benar membaca Variant, Master, atau invalid;
// - dipakai oleh preview create PO dan drawer detail PO.
// Hubungan flow aplikasi:
// - hanya presentasi read-only dari materialRequirementLines hasil service strict;
// - tidak mengubah submit PO, refresh need, Start Production, stok, payroll, atau HPP.
// Alasan logic:
// - material bervarian wajib tidak boleh terlihat normal sebagai Master bila resolver strict gagal/legacy mismatch.
// Status: AKTIF untuk preview/detail PO, GUARDED terhadap data legacy material requirement.
// =====================================================
const getRequirementStockSourceMeta = (line = {}) => {
  const variantLabel = line.resolvedVariantLabel || line.fixedVariantLabel || "";

  if (line.stockSourceType === "variant" || line.resolvedVariantKey || variantLabel) {
    return {
      color: "purple",
      label: "Variant",
      variantLabel: variantLabel || "Varian terpilih",
    };
  }

  if (lineRequiresVariantStock(line)) {
    return {
      color: "orange",
      label: "Varian tidak ditemukan",
      variantLabel: "Refresh Need / cek BOM",
    };
  }

  return {
    color: "default",
    label: "Master",
    variantLabel: "Tanpa varian",
  };
};

const getCompactLineStatus = (line = {}) => {
  const shortageQty = Number(line.shortageQty || 0);
  if (shortageQty > 0) {
    return {
      color: "red",
      label: `Kurang ${formatQtyWithUnit(shortageQty, line.unit)}`,
    };
  }

  return {
    color: "green",
    label: "Cukup",
  };
};

const ProductionOrders = () => {
  const { profile, firebaseUser } = useAuth();

  // =====================================================
  // IMS NOTE [AKTIF/GUARDED] - Actor audit Start Production dari PO.
  // Fungsi blok: mengirim user login ke service pembuatan Work Log agar metadata audit tidak jatuh ke "system".
  // Hubungan flow: hanya actor metadata; tidak mengubah requirement material, posting stok, PO lifecycle, payroll, atau HPP.
  // Alasan logic: Start Production dari halaman PO adalah jalur resmi yang membuat Work Log dan memotong material.
  // =====================================================
  const currentUser = useMemo(() => ({
    email: profile?.email || firebaseUser?.email || "",
    displayName: profile?.displayName || profile?.name || firebaseUser?.displayName || "",
    uid: profile?.authUid || profile?.uid || profile?.id || firebaseUser?.uid || "",
  }), [firebaseUser, profile]);

  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState([]);
  const [bomOptions, setBomOptions] = useState([]);
  const [bomLoading, setBomLoading] = useState(false);
  const [targetVariantOptions, setTargetVariantOptions] = useState([]);
  const [requirementPreview, setRequirementPreview] = useState(null);
  const [requirementPreviewLoading, setRequirementPreviewLoading] = useState(false);
  const [requirementPreviewError, setRequirementPreviewError] = useState("");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [targetTypeFilter, setTargetTypeFilter] = useState("all");

  const [formVisible, setFormVisible] = useState(false);
  const [detailVisible, setDetailVisible] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [, setCodeLoading] = useState(false);

  const [selectedOrder, setSelectedOrder] = useState(null);

  const [form] = Form.useForm();

  const targetTypeValue = Form.useWatch("targetType", form);
  const bomIdValue = Form.useWatch("bomId", form);
  const orderQtyValue = Form.useWatch("orderQty", form);
  const targetVariantKeyValue = Form.useWatch("targetVariantKey", form);
  const targetVariantLabelValue = Form.useWatch("targetVariantLabel", form);

  const loadData = async () => {
    try {
      setLoading(true);
      const result = await getAllProductionOrders();
      setOrders(result);
    } catch (error) {
      console.error(error);
      message.error("Gagal memuat production orders");
    } finally {
      setLoading(false);
    }
  };

  // =====================================================
  // Muat opsi BOM aktif untuk dropdown PO
  // Catatan maintainability:
  // - Dipanggil ulang saat buka form, ganti target type, fokus dropdown, dan buka dropdown
  // - Tujuannya agar BOM aktif terbaru selalu dipakai oleh menu PO
  // =====================================================
  const loadBomOptions = async (targetType = "product") => {
    try {
      setBomLoading(true);
      const result = await getActiveProductionBomOptions(targetType);
      setBomOptions(toReferenceOptions(result || []));
    } catch (error) {
      console.error(error);
      setBomOptions([]);
      message.error("Gagal memuat BOM aktif");
    } finally {
      setBomLoading(false);
    }
  };

  const loadGeneratedCode = async (targetType = "product") => {
    try {
      setCodeLoading(true);
      const nextCode = await generateProductionOrderCode(targetType);
      form.setFieldValue("code", nextCode || "");
    } catch (error) {
      console.error(error);
      form.setFieldValue("code", "");
    } finally {
      setCodeLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (targetTypeValue) {
      loadBomOptions(targetTypeValue);
    }
  }, [targetTypeValue]);

  useEffect(() => {
    const loadTargetVariants = async () => {
      if (!bomIdValue) {
        setTargetVariantOptions([]);
        form.setFieldsValue({
          targetVariantKey: undefined,
          targetVariantLabel: "",
        });
        return;
      }

      try {
        const result = await getProductionOrderTargetVariantOptions(bomIdValue);
        setTargetVariantOptions(result || []);

        if (!Array.isArray(result) || result.length === 0) {
          form.setFieldsValue({
            targetVariantKey: undefined,
            targetVariantLabel: "",
          });
        }
      } catch (error) {
        console.error(error);
        setTargetVariantOptions([]);
      }
    };

    loadTargetVariants();
  }, [bomIdValue, form]);

  useEffect(() => {
    let cancelled = false;

    const loadRequirementPreview = async () => {
      if (!bomIdValue || Number(orderQtyValue || 0) <= 0) {
        setRequirementPreview(null);
        setRequirementPreviewError("");
        return;
      }

      try {
        setRequirementPreviewLoading(true);
        setRequirementPreviewError("");
        const result = await buildProductionOrderRequirementLines({
          bomId: bomIdValue,
          orderQty: Number(orderQtyValue || 0),
          targetVariantKey: targetVariantKeyValue || "",
          targetVariantLabel: targetVariantLabelValue || "",
        });

        if (cancelled) return;

        const requirementLines = Array.isArray(result?.requirementLines)
          ? result.requirementLines
          : [];
        const totalRequired = requirementLines.reduce(
          (sum, line) => sum + Number(line.qtyRequired || 0),
          0,
        );
        const totalAvailable = requirementLines.reduce(
          (sum, line) => sum + Number(line.availableStockSnapshot || 0),
          0,
        );
        const totalShortage = requirementLines.reduce(
          (sum, line) => sum + Number(line.shortageQty || 0),
          0,
        );
        const topShortageLine = [...requirementLines]
          .filter((line) => Number(line.shortageQty || 0) > 0)
          .sort((left, right) => Number(right.shortageQty || 0) - Number(left.shortageQty || 0))[0];

        setRequirementPreview({
          // =====================================================
          // ACTIVE / FINAL - preview read-only Buat PO.
          // Fungsi:
          // - menyimpan line material dan snapshot stok target dari helper final;
          // - dipakai hanya untuk tampilan compact sebelum submit.
          // Alasan perubahan:
          // - kotak summary agregat terlalu penuh dan tidak memberi info stok target.
          // Status:
          // - aktif dipakai untuk drawer Buat Production Order;
          // - createProductionOrder tetap menghitung ulang requirement final saat simpan.
          // =====================================================
          requirementLines,
          targetStockPreview: result?.targetStockPreview || null,
          targetHasVariants:
            result?.targetHasVariants === true ||
            result?.targetStockPreview?.targetHasVariants === true ||
            result?.bom?.targetHasVariants === true,
          totalLines: Number(result?.reservationSummary?.totalLines || 0),
          sufficientLines: Number(result?.reservationSummary?.sufficientLines || 0),
          shortageLines: Number(result?.reservationSummary?.shortageLines || 0),
          canReserveFully: result?.reservationSummary?.canReserveFully === true,
          totalRequired,
          totalAvailable,
          totalShortage,
          topShortageLabel: topShortageLine
            ? `${topShortageLine.itemName || "Material"} kurang ${formatNumber(topShortageLine.shortageQty || 0)} ${topShortageLine.unit || ""}`
            : "",
        });
      } catch (error) {
        console.error(error);
        if (!cancelled) {
          setRequirementPreview(null);
          setRequirementPreviewError(
            error?.message || "Preview kebutuhan material gagal dimuat.",
          );
        }
      } finally {
        if (!cancelled) {
          setRequirementPreviewLoading(false);
        }
      }
    };

    loadRequirementPreview();

    return () => {
      cancelled = true;
    };
  }, [bomIdValue, orderQtyValue, targetVariantKeyValue, targetVariantLabelValue]);

  const summary = useMemo(() => {
    return buildCountSummary(orders, {
      shortage: (item) => item.status === "shortage",
      ready: (item) => item.status === "ready",
      inProduction: (item) => item.status === "in_production",
    });
  }, [orders]);

  const summaryItems = [
    {
      key: "production-orders-total",
      title: "Total Order",
      value: summary.total,
      subtitle: "Semua production order yang tersimpan.",
      accent: "primary",
    },
    {
      key: "production-orders-shortage",
      title: "Shortage",
      value: summary.shortage,
      subtitle: "Masih kurang material untuk mulai produksi.",
      accent: "warning",
    },
    {
      key: "production-orders-ready",
      title: "Ready",
      value: summary.ready,
      subtitle: "Sudah siap diproses menjadi work log produksi.",
      accent: "success",
    },
    {
      key: "production-orders-active",
      title: "In Production",
      value: summary.inProduction,
      subtitle: "Sedang berjalan di flow produksi aktif.",
      accent: "default",
    },
  ];

  const filteredData = useMemo(() => {
    return orders.filter((item) => {
      const matchSearch = createKeywordMatcher(
        {
          ...item,
          displayReference: buildDisplayReferenceSearchText(item, { fields: ["code", "productionOrderCode"] }),
        },
        ["code", "productionOrderCode", "displayReference", "targetName", "bomName"],
        search,
      );

      const matchStatus = matchFieldValue(item, statusFilter, "status");
      const matchTargetType = matchFieldValue(
        item,
        targetTypeFilter,
        "targetType",
      );

      return matchSearch && matchStatus && matchTargetType;
    });
  }, [orders, search, statusFilter, targetTypeFilter]);

  const handleAdd = async () => {
    form.resetFields();

    form.setFieldsValue({
      code: "",
      targetType: "product",
      bomId: undefined,
      targetVariantKey: undefined,
      targetVariantLabel: "",
      orderQty: 1,
      priority: "normal",
      notes: "",
    });

    setTargetVariantOptions([]);
    setFormVisible(true);

    await loadBomOptions("product");
    await loadGeneratedCode("product");
  };

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      const selectedVariant = targetVariantOptions.find(
        (item) => item.value === values.targetVariantKey,
      );

      setSubmitting(true);

      await createProductionOrder(
        {
          ...values,
          targetVariantLabel: selectedVariant?.label || "",
        },
        null,
      );

      message.success("Production order berhasil dibuat");

      setFormVisible(false);
      form.resetFields();
      await loadData();
    } catch (error) {
      if (error?.errorFields) return;

      if (error?.type === "validation" && error?.errors) {
        const fields = Object.entries(error.errors).map(([name, errors]) => ({
          name,
          errors: [errors],
        }));
        form.setFields(fields);
        return;
      }

      console.error(error);
      message.error(error?.message || "Gagal membuat production order");
    } finally {
      setSubmitting(false);
    }
  };

  const handleRefreshRequirement = async (record) => {
    try {
      await refreshProductionOrderRequirements(record.id, null);
      message.success("Kebutuhan material berhasil diperbarui");
      await loadData();
    } catch (error) {
      console.error(error);
      message.error(error?.message || "Gagal refresh kebutuhan order");
    }
  };

  // =====================================================
  // Mulai Produksi dari PO
  // Catatan maintainability:
  // - 1 PO = 1 Work Log
  // - Saat start, stok bahan dipotong sesuai requirement PO
  // - Work Log otomatis dibuat dari snapshot BOM/PO
  // =====================================================
  const handleStartProduction = async (record) => {
    try {
      await createProductionWorkLogFromOrder(record.id, {}, currentUser);
      message.success("Produksi dimulai. Work Log dibuat dan stok bahan dipotong.");
      await loadData();
    } catch (error) {
      console.error(error);
      message.error(error?.message || "Gagal memulai produksi");
    }
  };

  // =====================================================
  // Kolom list Production Order
  // Fungsi blok:
  // - menampilkan PO aktif dalam layout tabel yang compact;
  // - menjaga tombol aksi tetap langsung terlihat tanpa scroll horizontal.
  // Alasan perubahan:
  // - regression UI sebelumnya memakai scroll x besar sehingga tombol aksi terdorong ke kanan.
  // Status:
  // - aktif dipakai; bukan kandidat cleanup karena ini tabel utama Production Orders.
  // =====================================================
  const columns = [
    {
      title: "Order",
      key: "order",
      width: 170,
      render: (_, record) => (
        renderOrderCellBlock(resolveDisplayReference(record, { fields: ["code", "productionOrderCode"], fallback: "-" }), [
          `Dibuat: ${formatDateTimeLabel(record.createdAt)}`,
        ])
      ),
    },
    {
      title: "Target",
      key: "target",
      width: 250,
      render: (_, record) => (
        <div className={orderUiClassNames.stack}>
          <Space wrap size={[8, 4]} className="ims-cell-tag-list">
            <Typography.Text strong>{record.targetName || "-"}</Typography.Text>
            <Tag className="ims-status-tag" color={record.targetType === "product" ? "blue" : "purple"}>
              {record.targetType === "product" ? "Product" : "Semi Finished"}
            </Tag>
          </Space>
          <div className={orderUiClassNames.meta}>
            BOM: {record.bomCode || "-"} - {record.bomName || "-"}
          </div>
          {record.targetVariantLabel ? (
            <div className={orderUiClassNames.meta}>Varian: {record.targetVariantLabel}</div>
          ) : null}
          {/* =====================================================
              ACTIVE - referensi planning pada PO.
              Fungsi:
              - membantu user melihat PO ini berasal dari planning mana;
              - hanya info monitoring dan tidak mengubah flow stok/BOM.
          ===================================================== */}
          {record.planningCode ? (
            <div className={orderUiClassNames.meta}>
              Planning: {record.planningCode}{record.planningTitle ? ` - ${record.planningTitle}` : ""}
            </div>
          ) : null}
          <div className={orderUiClassNames.meta}>
            Estimasi Output: {formatNumber(record.expectedOutputQty || 0)} {record.targetUnit || "pcs"}
          </div>
        </div>
      ),
    },
    {
      title: "Priority",
      dataIndex: "priority",
      key: "priority",
      width: 92,
      render: (value) => {
        const meta = getPriorityMeta(value);
        return <Tag className="ims-status-tag" color={meta.color}>{meta.label}</Tag>;
      },
    },
    {
      title: "Qty Batch",
      dataIndex: "batchCount",
      key: "batchCount",
      width: 90,
      render: (_, record) => formatNumber(record.batchCount ?? record.orderQty),
    },
    {
      title: "Requirement",
      key: "requirement",
      width: 120,
      render: (_, record) => (
        <div className={orderUiClassNames.stack}>
          <Typography.Text>
            Line: {formatNumber(record.reservationSummary?.totalLines || 0)}
          </Typography.Text>
          <Typography.Text type="secondary" className={orderUiClassNames.meta}>
            Shortage: {formatNumber(record.reservationSummary?.shortageLines || 0)}
          </Typography.Text>
        </div>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 110,
      render: (value) => {
        const meta = ORDER_STATUS_MAP[value] || ORDER_STATUS_MAP.draft;
        return <span className="ims-badge-inline"><Badge status={meta.status} text={meta.text} /></span>;
      },
    },
    {
      title: "Aksi",
      key: "actions",
      width: 170,
      render: (_, record) => (
        // Aktif dipakai: aksi dibuat vertical compact agar Detail/Refresh/Mulai tetap terlihat tanpa scroll kanan.
        <Space direction="vertical" size={6} className="ims-action-group ims-action-group--vertical">
          <Button
            className="ims-action-button"
            size="small"
            icon={<EyeOutlined />}
            onClick={() => {
              setSelectedOrder(record);
              setDetailVisible(true);
            }}
          >
            Detail
          </Button>

          {(record.status === "shortage" || record.status === "ready") && (
            <Button
              className="ims-action-button"
              size="small"
              onClick={() => handleRefreshRequirement(record)}
            >
              Refresh Need
            </Button>
          )}

          {record.status === "ready" && (
            <Button
              className="ims-action-button"
              size="small"
              type="primary"
              onClick={() => handleStartProduction(record)}
            >
              Mulai Produksi
            </Button>
          )}
        </Space>
      ),
    },
  ];

  // =====================================================
  // SECTION: Detail requirement drawer compact columns — AKTIF
  // Fungsi:
  // - Menampilkan requirement material PO secara ringkas di drawer detail.
  //
  // Dipakai oleh:
  // - Drawer Detail Production Order pada halaman ProductionOrders.
  //
  // Alasan perubahan:
  // - Kolom tipe, stok, shortage, dan status dipadatkan agar drawer tidak perlu scroll horizontal besar.
  //
  // Catatan cleanup:
  // - Bisa diekstrak menjadi komponen shared jika detail requirement dipakai di halaman lain.
  //
  // Risiko:
  // - Jika field stok/shortage disembunyikan atau kalkulasi disentuh, audit kesiapan PO bisa salah.
  // =====================================================
  const detailRequirementColumns = useMemo(
    () => [
      {
        title: "Material",
        key: "item",
        width: 230,
        render: (_, record) => (
          <div className={orderUiClassNames.stack}>
            <Typography.Text strong>{record.itemName || "-"}</Typography.Text>
            <Typography.Text type="secondary" className={orderUiClassNames.meta}>
              {record.itemCode || "-"}
            </Typography.Text>
            <Tag
              className="ims-status-tag"
              color={record.itemType === "raw_material" ? "orange" : "blue"}
            >
              {record.itemType === "raw_material" ? "Raw Material" : "Semi Finished"}
            </Tag>
          </div>
        ),
      },
      {
        title: "Varian / Sumber",
        key: "variantSource",
        width: 170,
        render: (_, record) => {
          const sourceMeta = getRequirementStockSourceMeta(record);

          return (
            <div className={orderUiClassNames.stack}>
              <Tag className="ims-status-tag" color={sourceMeta.color}>
                {sourceMeta.label}
              </Tag>
              <Typography.Text type="secondary" className={orderUiClassNames.meta}>
                {sourceMeta.variantLabel}
              </Typography.Text>
            </div>
          );
        },
      },
      {
        title: "Kebutuhan / Stok",
        key: "quantityStock",
        width: 240,
        render: (_, record) => (
          <div className={orderUiClassNames.stack}>
            <Typography.Text strong>
              Need: {formatQtyWithUnit(record.qtyRequired, record.unit)}
            </Typography.Text>
            <Typography.Text type="secondary" className={orderUiClassNames.meta}>
              Current: {formatQtyWithUnit(record.currentStockSnapshot, record.unit)}
            </Typography.Text>
            <Typography.Text type="secondary" className={orderUiClassNames.meta}>
              Tersedia: {formatQtyWithUnit(record.availableStockSnapshot, record.unit)}
            </Typography.Text>
            {Number(record.reservedStockSnapshot || 0) > 0 ? (
              <Typography.Text type="secondary" className={orderUiClassNames.meta}>
                Reserved: {formatQtyWithUnit(record.reservedStockSnapshot, record.unit)}
              </Typography.Text>
            ) : null}
          </div>
        ),
      },
      {
        title: "Status",
        key: "lineStatus",
        width: 140,
        render: (_, record) => {
          const shortageQty = Number(record.shortageQty || 0);

          return (
            <div className={orderUiClassNames.stack}>
              {record.isSufficient ? (
                <Badge status="success" text="Cukup" />
              ) : (
                <Badge status="error" text="Kurang" />
              )}
              {shortageQty > 0 ? (
                <Tag className="ims-status-tag" color="red">
                  Kurang {formatQtyWithUnit(shortageQty, record.unit)}
                </Tag>
              ) : (
                <Tag className="ims-status-tag" color="green">Shortage 0</Tag>
              )}
            </div>
          );
        },
      },
    ],
    [],
  );

  return (
    <div className="page-container ims-page">
      {/* AKTIF / GUARDED: header shared produksi dipakai untuk konsistensi, flow order dan status transition tetap existing. */}
      <ProductionPageHeader
        title="Production Orders"
        description="Produksi mengikuti alur BOM → PO → Work Log."
        onAdd={handleAdd}
        addLabel="Buat Order"
      />

      {/* AKTIF / GUARDED: summary hanya migrasi wrapper presentational, tanpa ubah kalkulasi readiness/shortage. */}
      <ProductionSummaryCards items={summaryItems} />

      <ProductionFilterCard>
        <Col xs={24} md={8}>
          <Input
            placeholder="Cari kode, target, BOM..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            allowClear
          />
        </Col>

        <Col xs={24} md={8}>
          <Select
            className="ims-filter-control"
            value={targetTypeFilter}
            onChange={setTargetTypeFilter}
            options={[
              { value: "all", label: "Semua Target Type" },
              ...PRODUCTION_ORDER_TARGET_TYPES,
            ]}
          />
        </Col>

        <Col xs={24} md={8}>
          <Select
            className="ims-filter-control"
            value={statusFilter}
            onChange={setStatusFilter}
            options={[
              { value: "all", label: "Semua Status" },
              { value: "shortage", label: "Shortage" },
              { value: "ready", label: "Ready" },
                            { value: "in_production", label: "In Production" },
              { value: "completed", label: "Completed" },
                          ]}
          />
        </Col>
      </ProductionFilterCard>

      <PageSection
        title="Daftar Production Orders"
        subtitle="Cek shortage, readiness, dan akses Work Log."
      >
        {/* Aktif dipakai: scroll x besar dihapus agar tombol aksi terlihat pada desktop/laptop normal. */}
        <DataRefreshIndicator loading={loading} dataSource={filteredData} />
        <Table
          className="ims-table"
          rowKey="id"
          columns={columns}
          dataSource={filteredData}
          locale={{
            emptyText: getDataTableEmptyText(loading, <Empty description="Belum ada production order" />),
          }}
        />
      </PageSection>

      <Drawer
        title="Buat Production Order"
        open={formVisible}
        onClose={() => {
          setFormVisible(false);
          form.resetFields();
          setTargetVariantOptions([]);
        }}
        width={680}
        extra={
          <Space>
            <Button
              onClick={() => {
                setFormVisible(false);
                form.resetFields();
                setTargetVariantOptions([]);
              }}
            >
              Batal
            </Button>
            <Button type="primary" loading={submitting} onClick={handleSubmit}>
              Simpan
            </Button>
          </Space>
        }
      >
        <Alert
          style={{ marginBottom: 16 }}
          type="info"
          showIcon
          message="PO membaca BOM dan menandai Ready atau Shortage."
        />

        <Form form={form} layout="vertical">
          <Form.Item label="Kode Order" name="code">
            <Input
              placeholder="Auto generate"
              disabled
            />
          </Form.Item>

          <Form.Item
            label="Target Type"
            name="targetType"
            rules={[{ required: true, message: "Target type wajib dipilih" }]}
          >
            <Select
              options={PRODUCTION_ORDER_TARGET_TYPES}
              onChange={async (value) => {
                form.setFieldsValue({
                  code: "",
                  bomId: undefined,
                  targetVariantKey: undefined,
                  targetVariantLabel: "",
                });
                setTargetVariantOptions([]);
                await loadBomOptions(value);
                await loadGeneratedCode(value);
              }}
            />
          </Form.Item>

          <Form.Item
            label="BOM"
            name="bomId"
            rules={[{ required: true, message: "BOM wajib dipilih" }]}
          >
            <Select
              showSearch
              optionFilterProp="label"
              options={bomOptions}
              loading={bomLoading}
              placeholder="Pilih BOM..."
              onFocus={() => loadBomOptions(targetTypeValue || "product")}
              onDropdownVisibleChange={(open) => {
                if (open) loadBomOptions(targetTypeValue || "product");
              }}
              onChange={() => {
                form.setFieldsValue({
                  targetVariantKey: undefined,
                  targetVariantLabel: "",
                });
              }}
            />
          </Form.Item>

          {targetVariantOptions.length > 0 ? (
            <Form.Item
              label="Varian Target"
              name="targetVariantKey"
              rules={[
                { required: true, message: "Varian target wajib dipilih" },
              ]}
              extra="Pilih varian target jika ada."
            >
              <Select
                showSearch
                optionFilterProp="label"
                options={targetVariantOptions}
                placeholder="Pilih varian target..."
                onChange={(value) => {
                  const selectedVariant = targetVariantOptions.find(
                    (item) => item.value === value,
                  );
                  form.setFieldValue(
                    "targetVariantLabel",
                    selectedVariant?.label || "",
                  );
                }}
              />
            </Form.Item>
          ) : null}

          <Form.Item
            label="Qty Batch Produksi"
            name="orderQty"
            rules={[{ required: true, message: "Qty order wajib diisi" }]}
          >
            <InputNumber min={1} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
          </Form.Item>

          {/* =====================================================
              ACTIVE / FINAL - preview compact Buat Production Order.
              Fungsi:
              - mengganti kotak summary hijau besar dengan info target produksi
                dan kebutuhan material yang lebih berguna;
              - membaca requirementLines dan targetStockPreview dari helper final.
              Alasan perubahan:
              - drawer PO sebelumnya terlalu penuh oleh summary agregat.
              Status:
              - aktif dipakai sebagai preview read-only;
              - tidak menyimpan Firestore, tidak mengubah stok, dan tidak mengubah status PO.
          ===================================================== */}
          {bomIdValue && Number(orderQtyValue || 0) > 0 ? (
            <div style={{ marginBottom: 16 }}>
              {requirementPreviewError ? (
                <Alert
                  type="error"
                  showIcon
                  style={{ marginBottom: 12 }}
                  message="Preview kebutuhan material tidak valid"
                  description={requirementPreviewError}
                />
              ) : requirementPreview?.targetHasVariants === true && !targetVariantKeyValue ? (
                <Alert
                  type="info"
                  showIcon
                  style={{ marginBottom: 12 }}
                  message="Pilih varian target untuk preview kebutuhan."
                />
              ) : requirementPreview ? (
                <Space direction="vertical" size={12} style={{ width: "100%" }}>
                  <Card size="small" title="Target Produksi">
                    {(() => {
                      const targetPreview = requirementPreview.targetStockPreview || {};
                      const targetVariantLabel = targetPreview.targetVariantLabel || "";
                      const targetName = targetPreview.targetName || "-";
                      const targetUnit = targetPreview.targetUnit || "pcs";
                      const currentStockLabel =
                        targetPreview.currentStockSnapshot === null ||
                        targetPreview.currentStockSnapshot === undefined
                          ? targetPreview.note || "Stok target belum terbaca"
                          : formatQtyWithUnit(targetPreview.currentStockSnapshot, targetUnit);

                      return (
                        <Space direction="vertical" size={2} style={{ width: "100%" }}>
                          <Typography.Text strong>
                            {targetName}
                            {targetVariantLabel ? ` · ${targetVariantLabel}` : ""}
                          </Typography.Text>
                          <Typography.Text type="secondary">
                            Stok saat ini {currentStockLabel} · Qty batch {formatNumber(orderQtyValue || 0)} · Output {formatQtyWithUnit(targetPreview.expectedOutputQty || 0, targetUnit)}
                          </Typography.Text>
                        </Space>
                      );
                    })()}
                  </Card>

                  <Card
                    size="small"
                    title="Kebutuhan Material"
                    bodyStyle={{ padding: 12 }}
                  >
                    {requirementPreviewLoading ? (
                      <Typography.Text type="secondary">
                        Memuat preview kebutuhan material...
                      </Typography.Text>
                    ) : (requirementPreview.requirementLines || []).length === 0 ? (
                      <Typography.Text type="secondary">
                        BOM belum memiliki material.
                      </Typography.Text>
                    ) : (
                      <div style={{ maxHeight: 220, overflowY: "auto" }}>
                        {(requirementPreview.requirementLines || []).map((line, index) => {
                          const sourceMeta = getRequirementStockSourceMeta(line);
                          const statusMeta = getCompactLineStatus(line);

                          return (
                            <div
                              key={line.id || `${line.itemId || "material"}-${index}`}
                              style={{
                                padding: "8px 0",
                                borderBottom:
                                  index === requirementPreview.requirementLines.length - 1
                                    ? "none"
                                    : "1px solid #f0f0f0",
                              }}
                            >
                              <Space direction="vertical" size={2} style={{ width: "100%" }}>
                                <Typography.Text strong>
                                  {line.itemName || "Material"}
                                </Typography.Text>
                                <Space size={6} wrap>
                                  <Tag className="ims-status-tag" color={sourceMeta.color}>
                                    {sourceMeta.label}
                                  </Tag>
                                  <Typography.Text type="secondary">
                                    {sourceMeta.variantLabel}
                                  </Typography.Text>
                                  <Typography.Text type="secondary">·</Typography.Text>
                                  <Typography.Text type="secondary">
                                    Butuh {formatQtyWithUnit(line.qtyRequired, line.unit)}
                                  </Typography.Text>
                                  <Typography.Text type="secondary">·</Typography.Text>
                                  <Typography.Text type="secondary">
                                    Stok {formatQtyWithUnit(line.availableStockSnapshot, line.unit)}
                                  </Typography.Text>
                                  <Tag className="ims-status-tag" color={statusMeta.color}>
                                    {statusMeta.label}
                                  </Tag>
                                </Space>
                              </Space>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </Card>
                </Space>
              ) : (
                <Typography.Text type="secondary">
                  Memuat preview kebutuhan material...
                </Typography.Text>
              )}
            </div>
          ) : null}

          <Form.Item label="Priority" name="priority">
            <Select options={PRIORITY_OPTIONS} />
          </Form.Item>

          <Form.Item label="Catatan" name="notes">
            <Input.TextArea rows={3} placeholder="Catatan order..." />
          </Form.Item>
        </Form>
      </Drawer>
      <Drawer
        title="Detail Production Order"
        open={detailVisible}
        onClose={() => setDetailVisible(false)}
        width={920}
      >
        {!selectedOrder ? (
          <Empty description="Tidak ada data" />
        ) : (
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <Row gutter={[12, 12]}>
              <Col xs={24} sm={12} md={6}>
                <Card size="small">
                  <Statistic
                    title="Qty Batch"
                    value={formatNumber(selectedOrder.batchCount ?? selectedOrder.orderQty)}
                  />
                </Card>
              </Col>
              <Col xs={24} sm={12} md={6}>
                <Card size="small">
                  <Statistic
                    title="Estimasi Output"
                    value={formatNumber(selectedOrder.expectedOutputQty || 0)}
                    suffix={selectedOrder.targetUnit || "pcs"}
                  />
                </Card>
              </Col>
              <Col xs={24} sm={12} md={6}>
                <Card size="small">
                  <Typography.Text type="secondary">Priority</Typography.Text>
                  <div style={{ marginTop: 8 }}>
                    <Tag color={getPriorityMeta(selectedOrder.priority).color}>
                      {getPriorityMeta(selectedOrder.priority).label}
                    </Tag>
                  </div>
                </Card>
              </Col>
              <Col xs={24} sm={12} md={6}>
                <Card size="small">
                  <Typography.Text type="secondary">Status</Typography.Text>
                  <div style={{ marginTop: 8 }}>
                    <Badge
                      status={(ORDER_STATUS_MAP[selectedOrder.status] || ORDER_STATUS_MAP.draft).status}
                      text={(ORDER_STATUS_MAP[selectedOrder.status] || ORDER_STATUS_MAP.draft).text}
                    />
                  </div>
                </Card>
              </Col>
            </Row>

            {/* =====================================================
                Ringkasan order.
                Blok ini dipakai user operasional untuk membaca target, BOM,
                dan priority tanpa harus memindai tabel requirement. */}
            <Descriptions
              bordered
              size="small"
              column={1}
              title="Ringkasan Order"
            >
              <Descriptions.Item label="Kode">
                {resolveDisplayReference(selectedOrder, { fields: ["code", "productionOrderCode"], fallback: "-" })}
              </Descriptions.Item>
              <Descriptions.Item label="Target Type">
                {selectedOrder.targetType === "product" ? "Product" : "Semi Finished"}
              </Descriptions.Item>
              <Descriptions.Item label="Target">
                {selectedOrder.targetName || "-"}
              </Descriptions.Item>
              <Descriptions.Item label="Varian Target">
                {selectedOrder.targetVariantLabel || "-"}
              </Descriptions.Item>
              {/* =====================================================
                  ACTIVE - display planning reference.
                  Fungsi:
                  - PO manual lama tetap menampilkan tanda "-";
                  - PO dari planning punya jejak balik tanpa mengubah lifecycle PO.
              ===================================================== */}
              <Descriptions.Item label="Planning Reference">
                {selectedOrder.planningCode
                  ? `${selectedOrder.planningCode}${selectedOrder.planningTitle ? ` - ${selectedOrder.planningTitle}` : ""}`
                  : "-"}
              </Descriptions.Item>
              <Descriptions.Item label="BOM / Step">
                {selectedOrder.bomCode || "-"} - {selectedOrder.bomName || "-"}
              </Descriptions.Item>
              <Descriptions.Item label="Priority">
                <Tag color={getPriorityMeta(selectedOrder.priority).color}>
                  {getPriorityMeta(selectedOrder.priority).label}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Dibuat Pada">
                {formatDateTimeLabel(selectedOrder.createdAt)}
              </Descriptions.Item>
              <Descriptions.Item label="Mulai Produksi">
                {formatDateTimeLabel(selectedOrder.startedAt)}
              </Descriptions.Item>
              <Descriptions.Item label="Catatan">
                {selectedOrder.notes || "-"}
              </Descriptions.Item>
            </Descriptions>

            {(selectedOrder.reservationSummary?.shortageLines || 0) > 0 ? (
              <Alert
                type="error"
                showIcon
                message={`Ada ${formatNumber(
                  selectedOrder.reservationSummary?.shortageLines,
                )} item yang stoknya masih kurang.`}
                description="Cek requirement yang perlu disiapkan."
              />
            ) : (
              <Alert
                type="success"
                showIcon
                message="Semua kebutuhan material cukup dan siap untuk mulai produksi."
                description="PO siap masuk antrian produksi."
              />
            )}

            <Divider orientation="left">Requirement Material</Divider>

            <Table
              className="ims-table"
              rowKey="id"
              pagination={false}
              dataSource={selectedOrder.materialRequirementLines || []}
              columns={detailRequirementColumns}
              tableLayout="fixed"
            />
          </Space>
        )}
      </Drawer>
    </div>
  );
};

export default ProductionOrders;
