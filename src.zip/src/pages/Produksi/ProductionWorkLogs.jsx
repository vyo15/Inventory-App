// =====================================================
// Page: Work Log Produksi
// Revisi:
// - bisa ambil data/template dari BOM
// - bisa ambil data/template dari Production Order
// - Produksi lebih fokus ke eksekusi, bukan planning dari nol
// =====================================================

import { useCallback, useEffect, useMemo, useState } from "react";
import { buildCountSummary, createKeywordMatcher, matchFieldValue } from '../../utils/produksi/productionPageHelpers';
import { getWorkLogMaterialOptions, getWorkLogTargetOptions, toReferenceOptions } from '../../utils/produksi/productionReferenceHelpers';
import ProductionPageHeader from '../../components/Produksi/shared/ProductionPageHeader';
import SummaryStatGrid from '../../components/Layout/Display/SummaryStatGrid';
import ProductionFilterCard from '../../components/Produksi/shared/ProductionFilterCard';
import EditableLineSection from '../../components/Produksi/shared/EditableLineSection';
import {
  Button,
  Card,
  Col,
  DatePicker,
  Descriptions,
  Divider,
  Drawer,
  Empty,
  Form,
  Input,
  InputNumber,
  message,
  Modal,
  Popconfirm,
  Row,
  Select,
  Space,
  Table,
  Tag,
  Typography,
} from "antd";
import {
  DeleteOutlined,
  EditOutlined,
  EyeOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import {
  DEFAULT_PRODUCTION_WORK_LOG_FORM,
  DEFAULT_WORK_LOG_MATERIAL_USAGE,
  DEFAULT_WORK_LOG_OUTPUT,
  PRODUCTION_WORK_LOG_SOURCE_TYPES,
  PRODUCTION_WORK_LOG_STATUSES,
  WORK_LOG_SOURCE_TYPE_MAP,
  WORK_LOG_STATUS_MAP,
  WORK_LOG_TARGET_TYPE_MAP,
  calculateProductionMonitoring,
} from "../../constants/productionWorkLogOptions";
import {
  buildWorkLogDraftFromBom,
  buildWorkLogDraftFromProductionOrder,
  completeProductionWorkLog,
  createProductionWorkLogFromOrder,
  getAllProductionWorkLogs,
  getWorkLogReferenceData,
  updateProductionWorkLog,
} from "../../services/Produksi/productionWorkLogsService";
import {
  generatePayrollLinesFromCompletedWorkLog,
  getAllProductionPayrolls,
} from "../../services/Produksi/productionPayrollsService";
import { DataRefreshIndicator, getDataTableEmptyText } from "../../components/Layout/Feedback/DataLoadingState";
import formatNumber, { parseIntegerIdInput } from "../../utils/formatters/numberId";
import formatCurrency from "../../utils/formatters/currencyId";
import { getFormArrayValue, removeArrayItemByIndex, upsertArrayItemByIndex } from "../../utils/forms/formArrayHelpers";
import { buildWorkLogMaterialUsageFormLine, buildWorkLogOutputFormLine } from "../../utils/produksi/productionLineBuilders";
import { buildVariantOptionsFromItem, inferHasVariants } from "../../utils/variants/variantStockHelpers";
import { isProductionWorkLogCompleted } from "../../utils/produksi/productionFlowGuards";
import {
  buildProductionStepPayrollSnapshot,
  resolveWorkLogLaborCostDisplay,
} from "../../utils/produksi/productionPayrollRuleHelpers";
import { buildDisplayReferenceSearchText, resolveDisplayReference } from "../../utils/references/displayReferenceResolver";
import useAuth from "../../hooks/useAuth";

// IMS NOTE [AKTIF/GUARDED] - Standar input angka bulat
// Fungsi blok: mengarahkan InputNumber aktif ke step 1, precision 0, dan parser integer Indonesia.
// Hubungan flow: hanya membatasi input/display UI; service calculation stok, kas, HPP, payroll, dan report tidak diubah.
// Alasan logic: IMS operasional memakai angka tanpa desimal, sementara data lama decimal tidak dimigrasi otomatis.
// Behavior: input baru no-decimal; business rules dan schema Firestore tetap sama.

const safeNumber = (value, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const safeText = (value) => String(value || "").trim();

const findWorkLogStepMaster = (workLog = {}, productionSteps = []) =>
  (productionSteps || []).find((item) => {
    if (safeText(workLog.stepId) && safeText(item.id) === safeText(workLog.stepId)) return true;
    return safeText(workLog.stepCode) && safeText(item.code) === safeText(workLog.stepCode);
  }) || null;

const getScaledBomOverheadEstimate = ({ workLog = {}, boms = [] } = {}) => {
  const bom = (boms || []).find((item) => safeText(item.id) === safeText(workLog.bomId));
  const overheadPerBatch = safeNumber(bom?.overheadCostEstimate);
  if (overheadPerBatch <= 0) return 0;

  return overheadPerBatch * Math.max(1, safeNumber(workLog.plannedQty, 1));
};

const isEditableProductionWorkLog = (record = {}) =>
  safeText(record.status).toLowerCase() === "in_progress" && !isProductionWorkLogCompleted(record);

const getProductionPayrollsForWorkLogDisplaySafely = async () => {
  try {
    return await getAllProductionPayrolls();
  } catch (error) {
    console.error("Gagal memuat payroll untuk display detail Work Log", error);
    return [];
  }
};

const ProductionWorkLogs = () => {
  const { profile, firebaseUser } = useAuth();

  // =====================================================
  // IMS NOTE [AKTIF/GUARDED] - Actor audit Work Log.
  // Fungsi blok: mengirim user login ke service update/complete/payroll agar audit tidak jatuh ke "system".
  // Hubungan flow: hanya metadata createdBy/updatedBy/autoGeneratedBy; posting stok, payroll idempotency, HPP, dan lifecycle PO tidak diubah.
  // Alasan logic: Work Log completed sudah menyimpan operator produksi, tetapi actor aplikasi tetap perlu tercatat dari Auth session.
  // =====================================================
  const currentUser = useMemo(() => ({
    email: profile?.email || firebaseUser?.email || "",
    displayName: profile?.displayName || profile?.name || firebaseUser?.displayName || "",
    uid: profile?.authUid || profile?.uid || profile?.id || firebaseUser?.uid || "",
  }), [firebaseUser, profile]);

  // SECTION: state utama
  const [loading, setLoading] = useState(false);
  const [workLogs, setWorkLogs] = useState([]);
  const [productionPayrolls, setProductionPayrolls] = useState([]);
  const [referenceData, setReferenceData] = useState({
    boms: [],
    productionOrders: [],
    employees: [],
    rawMaterials: [],
    semiFinishedMaterials: [],
    products: [],
    productionSteps: [],
    productionProfiles: [],
  });

  // SECTION: state filter
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // SECTION: state form
  const [formVisible, setFormVisible] = useState(false);
  const [detailVisible, setDetailVisible] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [selectedRecord, setSelectedRecord] = useState(null);
  const [editingRecord, setEditingRecord] = useState(null);

  // SECTION: modal line
  const [materialModalVisible, setMaterialModalVisible] = useState(false);
  const [outputModalVisible, setOutputModalVisible] = useState(false);
  const [editingMaterialIndex, setEditingMaterialIndex] = useState(null);
  const [editingOutputIndex, setEditingOutputIndex] = useState(null);
  const [completeModalVisible, setCompleteModalVisible] = useState(false);
  const [completingRecord, setCompletingRecord] = useState(null);

  // SECTION: form instances
  const [form] = Form.useForm();
  const [materialForm] = Form.useForm();
  const [outputForm] = Form.useForm();
  const [completeForm] = Form.useForm();

  // SECTION: watch source
  const targetTypeValue = Form.useWatch("targetType", form);
  const targetIdValue = Form.useWatch("targetId", form);
  const stepIdValue = Form.useWatch("stepId", form);
  const productionProfileIdValue = Form.useWatch("productionProfileId", form);
  const goodQtyValue = Form.useWatch("goodQty", form);
  const baseInputQtyValue = Form.useWatch("baseInputQty", form);
  const leftoverLeafQtyValue = Form.useWatch("leftoverLeafQty", form);
  const leftoverStemQtyValue = Form.useWatch("leftoverStemQty", form);
  const leftoverPetalFlowerEquivalentValue = Form.useWatch("leftoverPetalFlowerEquivalent", form);

  const loadData = async () => {
    try {
      setLoading(true);
      const [workLogResult, refResult, payrollResult] = await Promise.all([
        getAllProductionWorkLogs(),
        getWorkLogReferenceData(),
        getProductionPayrollsForWorkLogDisplaySafely(),
      ]);

      setWorkLogs(workLogResult);
      setProductionPayrolls(Array.isArray(payrollResult) ? payrollResult : []);
      setReferenceData(refResult);

      if (Array.isArray(refResult?.metaWarnings) && refResult.metaWarnings.length > 0) {
        message.warning(refResult.metaWarnings[0]);
      }
    } catch (error) {
      console.error(error);
      message.error("Gagal memuat work log produksi");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);


  const summary = useMemo(() => {
    return buildCountSummary(workLogs, {
      completed: (item) => item.status === "completed",
      inProgress: (item) => item.status === "in_progress",
    });
  }, [workLogs]);

  // =====================================================
  // AKTIF UI-ONLY - Summary Work Log PO-first.
  // Fungsi blok:
  // - menampilkan KPI utama Work Log dengan pola SummaryStatGrid yang lebih compact dan konsisten;
  // - tidak menampilkan Cancelled sebagai KPI utama karena cancel bukan action aktif di halaman Work Log.
  // Hubungan flow:
  // - hanya presentasi data count; tidak mengubah status, service, stok, payroll, HPP, atau lifecycle PO.
  // =====================================================
  const summaryItems = useMemo(() => [
    {
      key: "total",
      title: "Total Work Log",
      value: formatNumber(summary.total || 0),
      subtitle: "Realisasi produksi yang tercatat",
      columns: { xs: 24, md: 8 },
    },
    {
      key: "progress",
      title: "Sedang Produksi",
      value: formatNumber(summary.inProgress || 0),
      subtitle: "Belum selesai / belum posting output",
      columns: { xs: 24, md: 8 },
    },
    {
      key: "completed",
      title: "Selesai",
      value: formatNumber(summary.completed || 0),
      subtitle: "Output sudah diproses ke flow selesai",
      columns: { xs: 24, md: 8 },
    },
  ], [summary.completed, summary.inProgress, summary.total]);

  const filteredData = useMemo(() => {
    return workLogs.filter((item) => {
      const matchSearch = createKeywordMatcher(
        {
          ...item,
          displayReference: buildDisplayReferenceSearchText(item, { fields: ["workNumber", "productionOrderCode"] }),
        },
        ["workNumber", "productionOrderCode", "displayReference", "targetName", "stepName"],
        search,
      );

      const matchStatus = matchFieldValue(item, statusFilter, "status");

      return matchSearch && matchStatus;
    });
  }, [workLogs, search, statusFilter]);

  const resetFormState = () => {
    setEditingRecord(null);
    form.resetFields();
    form.setFieldsValue({
      ...DEFAULT_PRODUCTION_WORK_LOG_FORM,
      workDate: dayjs(),
      sourceType: "production_order",
      status: "in_progress",
      materialUsages: [],
      outputs: [],
      workerIds: [],
      productionOrderId: undefined,
      productionProfileId: undefined,
    });
  };

  // =====================================================
  // Handler edit work log
  // Catatan:
  // - drawer form masih dipakai untuk mode edit data Work Log existing
  // - Work Log baru dibuat dari action Mulai Produksi di Production Order, bukan tombol tambah manual di halaman ini
  // =====================================================
  const handleEdit = (record) => {
    if (!isEditableProductionWorkLog(record)) {
      message.warning("Work Log yang sudah completed tidak bisa diedit dari UI utama.");
      return;
    }

    setEditingRecord(record);
    form.setFieldsValue({
      ...DEFAULT_PRODUCTION_WORK_LOG_FORM,
      ...record,
      workDate: record.workDate
        ? dayjs(record.workDate?.toDate?.() || record.workDate)
        : null,
    });
    setFormVisible(true);
  };

  const handleViewDetail = (record) => {
    setSelectedRecord(record);
    setDetailVisible(true);
  };

  // =====================================================
  // Helper options
  // =====================================================
  const productionOrderOptions = toReferenceOptions(
    referenceData.productionOrders || [],
  );

  const employeeOptions = toReferenceOptions(referenceData.employees || []);

  const stepOptions = toReferenceOptions(referenceData.productionSteps || []);

  const getTargetOptions = (targetType) =>
    getWorkLogTargetOptions(referenceData, targetType);

  const getProductionProfileOptions = (targetId) =>
    (referenceData.productionProfiles || [])
      .filter((item) => item.productId === targetId)
      .map((item) => ({
        value: item.id,
        label: `${item.profileName || '-'}${item.isDefault !== false ? ' (Default)' : ''}`,
      }));

  const getMaterialOptions = (itemType) =>
    getWorkLogMaterialOptions(referenceData, itemType);


  const selectedProductionProfile = useMemo(
    () =>
      (referenceData.productionProfiles || []).find(
        (item) => item.id === productionProfileIdValue,
      ) || null,
    [referenceData.productionProfiles, productionProfileIdValue],
  );

  const selectedStepForMonitoring = useMemo(
    () =>
      (referenceData.productionSteps || []).find(
        (item) => item.id === stepIdValue,
      ) || null,
    [referenceData.productionSteps, stepIdValue],
  );

  const monitoringPreview = useMemo(
    () =>
      calculateProductionMonitoring(
        {
          ...(selectedProductionProfile || {}),
          basisType: selectedStepForMonitoring?.basisType || '',
          referenceYieldPerBaseQty:
            selectedStepForMonitoring?.basisType === 'per_meter'
              ? (selectedStepForMonitoring?.name || '').toLowerCase().includes('daun')
                ? selectedProductionProfile?.leafYieldPerMeter
                : selectedProductionProfile?.petalYieldPerMeter
              : selectedStepForMonitoring?.basisType === 'per_rod_40cm'
                ? selectedProductionProfile?.stemYieldPerRod40cm
                : 0,
          flowerEquivalentPerBaseQty:
            selectedStepForMonitoring?.basisType === 'per_meter'
              ? (selectedStepForMonitoring?.name || '').toLowerCase().includes('daun')
                ? selectedProductionProfile?.flowerEquivalentPerLeafMeter
                : selectedProductionProfile?.flowerEquivalentPerPetalMeter
              : selectedStepForMonitoring?.basisType === 'per_rod_40cm'
                ? selectedProductionProfile?.flowerEquivalentPerRod40cm
                : 0,
          batchLeafQty:
            (selectedProductionProfile?.assemblyLeafPackCount || 0) *
            (selectedProductionProfile?.leafYieldPerMeter || 0),
          batchStemQty: selectedProductionProfile?.assemblyStemQty || 0,
        },
        {
          basisType: selectedStepForMonitoring?.basisType || '',
          baseInputQty: baseInputQtyValue,
          goodQty: goodQtyValue,
          leftoverLeafQty: leftoverLeafQtyValue,
          leftoverStemQty: leftoverStemQtyValue,
          leftoverPetalFlowerEquivalent: leftoverPetalFlowerEquivalentValue,
        },
      ),
    [
      selectedProductionProfile,
      selectedStepForMonitoring,
      baseInputQtyValue,
      goodQtyValue,
      leftoverLeafQtyValue,
      leftoverStemQtyValue,
      leftoverPetalFlowerEquivalentValue,
    ],
  );

  /* =====================================================
  SECTION: Apply BOM Template To Work Log — LEGACY-COMPAT/GUARDED
  Fungsi:
  - Mengisi form Work Log dari BOM sebagai template eksekusi, bukan membuat status Draft baru.

  Dipakai oleh:
  - Tombol Ambil Data BOM di drawer Work Log.

  Alasan perubahan:
  - Nama helper service lama tetap kompatibel (`buildWorkLogDraftFromBom`), tetapi UI aktif tidak lagi memakai konsep Draft Work Log.

  Catatan cleanup:
  - Nama helper service bisa dirapikan pada refactor non-fungsional terpisah.

  Risiko:
  - Jika status form ikut dikembalikan ke Draft, flow produksi bisa melewati start/in_progress yang dipakai PO dan stok.
  ===================================================== */
  const handleApplyBomTemplate = (bomId) => {
    const bom = (referenceData.boms || []).find((item) => item.id === bomId);

    if (!bom) {
      message.error("BOM tidak ditemukan");
      return;
    }

    const templateValues = buildWorkLogDraftFromBom(bom);

    form.setFieldsValue({
      ...form.getFieldsValue(),
      ...templateValues,
      status: "in_progress",
    });

    message.success("Data BOM berhasil dimasukkan ke Work Log");
  };

  /* =====================================================
  SECTION: Apply Production Order Template To Work Log — LEGACY-COMPAT/GUARDED
  Fungsi:
  - Mengisi form Work Log dari Production Order sebagai template eksekusi, bukan membuat status Draft baru.

  Dipakai oleh:
  - Tombol Ambil Data PO dan perubahan pilihan Production Order di drawer Work Log.

  Alasan perubahan:
  - Helper service `buildWorkLogDraftFromProductionOrder` tetap dipertahankan demi kompatibilitas, tetapi label dan status UI aktif tidak lagi Draft.

  Catatan cleanup:
  - Nama helper service bisa dirapikan pada batch refactor setelah flow produksi stabil.

  Risiko:
  - Jika data PO diterapkan dengan status Draft, Work Log baru bisa tidak sesuai lifecycle eksekusi dan status PO.
  ===================================================== */
  const handleApplyProductionOrderTemplate = async (orderId) => {
    try {
      const productionOrder = (referenceData.productionOrders || []).find(
        (item) => item.id === orderId,
      );

      if (!productionOrder) {
        message.error("Production order tidak ditemukan");
        return;
      }

      const templateValues = await buildWorkLogDraftFromProductionOrder(productionOrder);

      form.setFieldsValue({
        ...form.getFieldsValue(),
        ...templateValues,
        sourceType: "production_order",
        status: "in_progress",
      });

      message.success("Data Order Produksi berhasil dimasukkan ke Work Log");
    } catch (error) {
      console.error(error);
      message.error(error?.message || "Gagal mengambil data PO");
    }
  };

  // =====================================================
  // Modal material usage
  // =====================================================
  const openMaterialModal = (index = null, record = null) => {
    setEditingMaterialIndex(index);
    materialForm.setFieldsValue(
      record
        ? { ...DEFAULT_WORK_LOG_MATERIAL_USAGE, ...record }
        : DEFAULT_WORK_LOG_MATERIAL_USAGE,
    );
    setMaterialModalVisible(true);
  };

  // =====================================================
  // Modal output
  // =====================================================
  const openOutputModal = (index = null, record = null) => {
    setEditingOutputIndex(index);
    outputForm.setFieldsValue(
      record
        ? { ...DEFAULT_WORK_LOG_OUTPUT, ...record }
        : DEFAULT_WORK_LOG_OUTPUT,
    );
    setOutputModalVisible(true);
  };

  const handleSaveMaterialUsage = async () => {
    try {
      const values = await materialForm.validateFields();
      const options = getMaterialOptions(values.itemType);
      const selected = options.find(
        (item) => item.value === values.itemId,
      )?.raw;

      const line = buildWorkLogMaterialUsageFormLine({
        values,
        selectedItem: selected,
      });

      const current = getFormArrayValue(form, "materialUsages");
      const next = upsertArrayItemByIndex(
        current,
        editingMaterialIndex,
        line,
      );

      form.setFieldValue("materialUsages", next);
      setMaterialModalVisible(false);
      setEditingMaterialIndex(null);
      materialForm.resetFields();
    } catch (error) {
      if (error?.errorFields) return;
      console.error(error);
      message.error("Gagal menyimpan material usage");
    }
  };

  const handleRemoveMaterialUsage = (index) => {
    const current = getFormArrayValue(form, "materialUsages");
    form.setFieldValue(
      "materialUsages",
      removeArrayItemByIndex(current, index),
    );
  };

  const handleSaveOutput = async () => {
    try {
      const values = await outputForm.validateFields();

      const options =
        values.outputType === "semi_finished_material"
          ? (referenceData.semiFinishedMaterials || []).map((item) => ({
              value: item.id,
              raw: item,
            }))
          : (referenceData.products || []).map((item) => ({
              value: item.id,
              raw: item,
            }));

      const selected = options.find(
        (item) => item.value === values.outputIdRef,
      )?.raw;

      const line = buildWorkLogOutputFormLine({
        values: {
          ...values,
          rejectQty: 0,
          reworkQty: 0,
        },
        selectedOutput: selected,
      });

      const current = getFormArrayValue(form, "outputs");
      const next = upsertArrayItemByIndex(
        current,
        editingOutputIndex,
        line,
      );

      form.setFieldValue("outputs", next);
      setOutputModalVisible(false);
      setEditingOutputIndex(null);
      outputForm.resetFields();
    } catch (error) {
      if (error?.errorFields) return;
      console.error(error);
      message.error("Gagal menyimpan output");
    }
  };

  const handleRemoveOutput = (index) => {
    const current = getFormArrayValue(form, "outputs");
    form.setFieldValue(
      "outputs",
      removeArrayItemByIndex(current, index),
    );
  };

  // =====================================================
  // Submit work log
  // Jika sourceType = production_order dan belum ada editing record,
  // create langsung dari order agar status PO ikut in_production
  // =====================================================
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      const selectedTarget = getTargetOptions(values.targetType).find(
        (item) => item.value === values.targetId,
      )?.raw;

      const selectedStep = (referenceData.productionSteps || []).find(
        (item) => item.id === values.stepId,
      );

      const selectedEmployees = (referenceData.employees || []).filter((item) =>
        (values.workerIds || []).includes(item.id),
      );

      const selectedProfile = (referenceData.productionProfiles || []).find(
        (item) => item.id === values.productionProfileId,
      );

      const selectedStepPayrollSnapshot = selectedStep
        ? buildProductionStepPayrollSnapshot(selectedStep)
        : null;

      const payload = {
        ...values,
        workDate: values.workDate ? values.workDate.toDate() : null,
        targetCode: selectedTarget?.code || "",
        targetName: selectedTarget?.name || "",
        targetUnit: selectedTarget?.unit || values.targetUnit || "pcs",
        productionProfileName: selectedProfile?.profileName || '',
        productionProfile: {
          ...(selectedProfile || {}),
          basisType: selectedStep?.basisType || '',
          referenceYieldPerBaseQty:
            selectedStep?.basisType === 'per_meter'
              ? (selectedStep?.name || '').toLowerCase().includes('daun')
                ? selectedProfile?.leafYieldPerMeter
                : selectedProfile?.petalYieldPerMeter
              : selectedStep?.basisType === 'per_rod_40cm'
                ? selectedProfile?.stemYieldPerRod40cm
                : 0,
          flowerEquivalentPerBaseQty:
            selectedStep?.basisType === 'per_meter'
              ? (selectedStep?.name || '').toLowerCase().includes('daun')
                ? selectedProfile?.flowerEquivalentPerLeafMeter
                : selectedProfile?.flowerEquivalentPerPetalMeter
              : selectedStep?.basisType === 'per_rod_40cm'
                ? selectedProfile?.flowerEquivalentPerRod40cm
                : 0,
          batchLeafQty:
            (selectedProfile?.assemblyLeafPackCount || 0) *
            (selectedProfile?.leafYieldPerMeter || 0),
          batchStemQty: selectedProfile?.assemblyStemQty || 0,
        },
        stepCode: selectedStep?.code || "",
        stepName: selectedStep?.name || "",
        sequenceNo: values.sequenceNo || 1,
        ...(selectedStepPayrollSnapshot
          ? {
              stepPayrollMode: selectedStepPayrollSnapshot.payrollMode,
              stepPayrollRate: selectedStepPayrollSnapshot.payrollRate,
              stepPayrollQtyBase: selectedStepPayrollSnapshot.payrollQtyBase,
              stepPayrollOutputBasis: selectedStepPayrollSnapshot.payrollOutputBasis,
              stepPayrollClassification: selectedStepPayrollSnapshot.payrollClassification,
              stepPayrollIncludeInHpp: selectedStepPayrollSnapshot.includePayrollInHpp,
              stepPayrollRuleSource: "production_step",
            }
          : {}),
        workerCodes: selectedEmployees.map((item) => item.code || ""),
        workerNames: selectedEmployees.map((item) => item.name || ""),
        workerCount: selectedEmployees.length,
      };

      setSubmitting(true);

      if (editingRecord?.id) {
        await updateProductionWorkLog(editingRecord.id, payload, currentUser);
        message.success("Work log produksi berhasil diperbarui");
      } else if (
        payload.sourceType === "production_order" &&
        payload.productionOrderId
      ) {
        await createProductionWorkLogFromOrder(
          payload.productionOrderId,
          payload,
          currentUser,
        );
        message.success("Work log dari Order Produksi berhasil dibuat");
      } else {
        message.error("Work Log baru harus dimulai dari Order Produksi melalui tombol Mulai Produksi.");
        return;
      }

      setFormVisible(false);
      resetFormState();
      await loadData();
    } catch (error) {
      if (error?.errorFields) return;

      if (error?.type === "validation" && error?.errors) {
        const normalFields = [];
        const globalMessages = [];

        Object.entries(error.errors).forEach(([name, errors]) => {
          if (["materialUsages", "outputs"].includes(name)) {
            globalMessages.push(errors);
          } else {
            normalFields.push({
              name,
              errors: [errors],
            });
          }
        });

        if (normalFields.length > 0) {
          form.setFields(normalFields);
        }

        if (globalMessages.length > 0) {
          message.error(globalMessages[0]);
        }
        return;
      }

      console.error(error);
      message.error(error?.message || "Gagal menyimpan work log produksi");
    } finally {
      setSubmitting(false);
    }
  };

  // =====================================================
  // Popup selesai produksi
  // Catatan maintainability:
  // - User isi Good Qty, operator, dan catatan dari popup ini; field hasil selain good hanya compatibility data lama.
  // - Setelah update work log, baru service complete menambah stok output dan menutup PO
  // =====================================================
  const handleOpenComplete = (record) => {
    setCompletingRecord(record);
    completeForm.setFieldsValue({
      goodQty: record.goodQty || 0,
      workerIds: Array.isArray(record.workerIds) ? record.workerIds : [],
      notes: record.notes || '',
    });
    setCompleteModalVisible(true);
  };

  const handleMarkCompleted = async () => {
    try {
      const values = await completeForm.validateFields();
      if (!completingRecord?.id) return;

      await updateProductionWorkLog(
        completingRecord.id,
        {
          ...completingRecord,
          goodQty: values.goodQty,
          rejectQty: 0,
          reworkQty: 0,
          scrapQty: 0,
          workerIds: values.workerIds || [],
          workerNames: (referenceData.employees || [])
            .filter((item) => (values.workerIds || []).includes(item.id))
            .map((item) => item.name || ''),
          workerCodes: (referenceData.employees || [])
            .filter((item) => (values.workerIds || []).includes(item.id))
            .map((item) => item.code || ''),
          workerCount: Array.isArray(values.workerIds) ? values.workerIds.length : 0,
          notes: values.notes || '',
        },
        currentUser,
      );

      await completeProductionWorkLog(completingRecord.id, currentUser);
      // =====================================================
      // ACTIVE / GUARDED - auto payroll setelah Work Log selesai
      // Fungsi blok:
      // - membuat payroll line otomatis dari Work Log completed;
      // - menjaga flow lama output stok tetap selesai dulu, lalu payroll dibuat dengan guard idempotent.
      // Alasan blok ini dipakai:
      // - regression sebelumnya Work Log selesai tetapi Payroll Produksi tetap kosong.
      // Status:
      // - aktif dipakai; bukan legacy dan tidak mengubah business rule stok/HPP.
      // =====================================================
      let payrollMessageHandled = false;
      try {
        const payrollResult = await generatePayrollLinesFromCompletedWorkLog(completingRecord.id, currentUser);
        const createdPayrollCount = Number(payrollResult?.createdCount || 0);
        const skippedPayrollCount = Number(payrollResult?.skippedCount || 0);

        if (createdPayrollCount > 0) {
          payrollMessageHandled = true;
          message.success(`Work log selesai dan ${createdPayrollCount} line payroll dibuat.`);
        } else if (skippedPayrollCount > 0) {
          payrollMessageHandled = true;
          message.info('Work log selesai. Payroll sudah pernah dibuat, tidak dibuat dobel.');
        }
      } catch (payrollError) {
        // =====================================================
        // ACTIVE / GUARDED - fallback error payroll setelah complete
        // Fungsi blok:
        // - menjaga user tahu bahwa Work Log sudah selesai meski auto payroll gagal;
        // - tidak menjalankan ulang complete agar output stok tidak dobel.
        // Alasan blok ini dipakai:
        // - complete Work Log adalah guarded stock flow, sedangkan payroll bisa diperbaiki via task terpisah/manual.
        // Status:
        // - aktif sebagai guard; bukan legacy.
        // =====================================================
        console.error(payrollError);
        payrollMessageHandled = true;
        message.warning(payrollError?.message || 'Work log selesai, tetapi payroll otomatis gagal dibuat.');
      }

      if (!payrollMessageHandled) {
        message.success('Work log selesai. Output ditambahkan dan PO ditutup.');
      }
      setCompleteModalVisible(false);
      setCompletingRecord(null);
      completeForm.resetFields();
      await loadData();
    } catch (error) {
      if (error?.errorFields) return;
      console.error(error);
      message.error(error?.message || 'Gagal menyelesaikan work log');
    }
  };


  // =====================================================
  // Helper presentasi daftar & drawer detail
  // Catatan maintainability:
  // - Helper di bawah hanya untuk kebutuhan tampilan / readability UI.
  // - Jangan dipakai untuk mengubah logika transaksi, stok, atau status produksi.
  // - Tujuannya agar tampilan work log tetap rapi, profesional, dan mudah diaudit.
  // =====================================================
  const formatDisplayDate = (value, format = "DD/MM/YYYY") => {
    const rawValue = value?.toDate ? value.toDate() : value;
    return rawValue ? dayjs(rawValue).format(format) : "-";
  };

  const getWorkLogStatusTagColor = (status) => {
    switch (status) {
      case "completed":
        return "green";
      case "in_progress":
        return "blue";
      case "cancelled":
        return "red";
      case "draft":
      default:
        return "default";
    }
  };

  const getWorkLogSourceTagColor = (sourceType) =>
    sourceType === "production_order" ? "purple" : "blue";

  const getStockSourceTagColor = useCallback(
    (stockSourceType) => (stockSourceType === "variant" ? "purple" : "default"),
    [],
  );

  // =====================================================
  // Helper presentasi batch 1.
  // Dipakai untuk mengganti blok metadata tabel yang sebelumnya banyak inline
  // style menjadi class shared agar lebih rapi dan mudah di-maintain.
  // =====================================================
  const workLogUiClassNames = useMemo(
    () => ({
      stack: "ims-cell-stack ims-cell-stack-tight",
      meta: "ims-cell-meta",
      title: "ims-cell-title",
    }),
    [],
  );

  const renderWorkLogCellBlock = useCallback(
    (primary, secondaryLines = []) => (
      <div className={workLogUiClassNames.stack}>
        <div className={workLogUiClassNames.title}>{primary || "-"}</div>
        {secondaryLines.filter(Boolean).map((line, index) => (
          <div key={index} className={workLogUiClassNames.meta}>{line}</div>
        ))}
      </div>
    ),
    [workLogUiClassNames.meta, workLogUiClassNames.stack, workLogUiClassNames.title],
  );

  // =====================================================
  // ACTIVE UI GUARD - konteks estimasi modal complete Work Log.
  // Fungsi blok:
  // - memberi acuan target, step, batch, dan estimasi hasil sebelum user mengisi Good Qty.
  // Alasan perubahan:
  // - regression UI sebelumnya menghapus konteks output sehingga user tidak punya acuan cepat saat menyelesaikan work log.
  // Status:
  // - aktif dipakai hanya sebagai preview read-only; bukan business rule dan bukan kandidat cleanup.
  // =====================================================
  const renderCompleteWorkLogEstimateInfo = (record) => {
    if (!record) return null;

    const unitLabel = record.targetUnit || record.unit || "";
    const targetLabel = [record.targetName || "-", record.targetVariantLabel ? `Varian: ${record.targetVariantLabel}` : null]
      .filter(Boolean)
      .join(" · ");

    return (
      <Card
        size="small"
        className="ims-readonly-panel"
        style={{ marginBottom: 16 }}
        bodyStyle={{ padding: 12 }}
      >
        <Space direction="vertical" size={4} style={{ width: "100%" }}>
          <Space size={6} wrap>
            <Typography.Text strong>Acuan estimasi hasil</Typography.Text>
            <Tag color="default">Read-only</Tag>
          </Space>
          <Typography.Text>{targetLabel}</Typography.Text>
          <Typography.Text type="secondary" className="ims-cell-meta">
            Tahapan: {record.stepName || "-"} · No. Order: {record.productionOrderCode || "-"}
          </Typography.Text>
          <Typography.Text type="secondary" className="ims-cell-meta">
            Qty batch: {formatNumber(record.plannedQty || 0)} · Estimasi hasil: {formatNumber(record.theoreticalOutputQty || 0)} {unitLabel}
          </Typography.Text>
        </Space>
      </Card>
    );
  };

  // =====================================================
  // Data turunan drawer detail
  // - Semua data di bawah dibentuk dari selectedRecord aktif.
  // - Dengan pola ini, drawer detail lebih mudah dirapikan tanpa mencampur
  //   logika presentasi dengan markup yang terlalu panjang.
  // =====================================================
  const detailWorkerNames = useMemo(() => {
    if (!selectedRecord || !Array.isArray(selectedRecord.workerNames)) {
      return [];
    }

    return selectedRecord.workerNames.filter(Boolean);
  }, [selectedRecord]);

  const detailRelatedPayrolls = useMemo(() => {
    if (!selectedRecord) return [];

    const workLogId = safeText(selectedRecord.id);
    const workNumber = safeText(selectedRecord.workNumber);

    return productionPayrolls.filter((item) => (
      (workLogId && safeText(item.workLogId) === workLogId) ||
      (workNumber && safeText(item.workNumber) === workNumber)
    ));
  }, [productionPayrolls, selectedRecord]);

  // =====================================================
  // ACTIVE UI-ONLY - display labor Work Log yang compact.
  // Fungsi:
  // - payroll final tetap prioritas dan satu-satunya nilai yang masuk HPP final;
  // - payroll draft/estimasi Step boleh tampil read-only agar user paham kenapa field
  //   `laborCostActual` masih 0 sebelum payroll final;
  // - tidak menulis balik estimasi ke Work Log dan tidak membuat payroll otomatis.
  // =====================================================
  const detailLaborCostDisplay = useMemo(() => {
    if (!selectedRecord) {
      return { amount: 0, label: "-", tagColor: "default", helper: "-" };
    }

    return resolveWorkLogLaborCostDisplay({
      workLog: selectedRecord,
      relatedPayrolls: detailRelatedPayrolls,
      productionStep: findWorkLogStepMaster(selectedRecord, referenceData.productionSteps || []),
    });
  }, [detailRelatedPayrolls, referenceData.productionSteps, selectedRecord]);

  const detailLaborDisplay = detailLaborCostDisplay.amount || detailLaborCostDisplay.displayAmount || 0;

  const detailOverheadCostDisplay = useMemo(() => {
    if (!selectedRecord) {
      return { amount: 0, label: "-", tagColor: "default", helper: "-" };
    }

    const overheadActual = safeNumber(selectedRecord.overheadCostActual);
    if (overheadActual > 0) {
      return {
        amount: overheadActual,
        label: "Dari Resep Produksi",
        tagColor: "blue",
        helper: "Overhead dari resep produksi.",
      };
    }

    const overheadEstimate = getScaledBomOverheadEstimate({
      workLog: selectedRecord,
      boms: referenceData.boms || [],
    });

    if (overheadEstimate > 0) {
      return {
        amount: overheadEstimate,
        label: "Estimasi Resep",
        tagColor: "default",
        helper: "Info data lama; belum disimpan sebagai overhead aktual.",
      };
    }

    return {
      amount: 0,
      label: "Tidak dipakai",
      tagColor: "default",
      helper: "Overhead resep belum diisi.",
    };
  }, [referenceData.boms, selectedRecord]);

  const detailDisplayedTotalCost = selectedRecord
    ? safeNumber(selectedRecord.materialCostActual) +
      safeNumber(detailOverheadCostDisplay.amount) +
      safeNumber(detailLaborDisplay)
    : 0;
  const detailDisplayedCostPerGoodUnit =
    selectedRecord && safeNumber(selectedRecord.goodQty) > 0
      ? detailDisplayedTotalCost / safeNumber(selectedRecord.goodQty)
      : 0;

  const detailMetricCards = useMemo(() => {
    if (!selectedRecord) return [];

    const unitLabel = selectedRecord.targetUnit || "pcs";

    return [
      {
        key: "batch",
        label: "Qty Batch",
        value: formatNumber(selectedRecord.plannedQty || 0),
        helper: "Jumlah batch yang dikerjakan",
      },
      {
        key: "estimate",
        label: "Estimasi Output",
        value: `${formatNumber(selectedRecord.theoreticalOutputQty || 0)} ${unitLabel}`,
        helper: `Tahapan: ${selectedRecord.stepName || "-"}`,
      },
      {
        key: "good",
        label: "Hasil Baik",
        value: `${formatNumber(selectedRecord.goodQty || 0)} ${unitLabel}`,
        helper: "Qty yang masuk stok/output produksi",
      },
      {
        key: "cost",
        label: detailLaborCostDisplay.isFinal ? "Total Biaya Final" : "Estimasi Biaya",
        value: formatCurrency(detailDisplayedTotalCost),
        helper: detailLaborCostDisplay.isFinal
          ? `Cost / good unit ${formatCurrency(detailDisplayedCostPerGoodUnit)}`
          : `${detailLaborCostDisplay.totalStatusLabel || "Preview"}; final menunggu payroll confirmed/paid.`,
      },
    ];
  }, [
    detailDisplayedCostPerGoodUnit,
    detailDisplayedTotalCost,
    detailLaborCostDisplay.isFinal,
    detailLaborCostDisplay.totalStatusLabel,
    selectedRecord,
  ]);

  const detailMaterialColumns = useMemo(
    () => [
      {
        title: "Material",
        key: "item",
        render: (_, record) => (
          renderWorkLogCellBlock(record.itemName || "-", [
            record.resolvedVariantLabel ? `Varian: ${record.resolvedVariantLabel}` : null,
          ])
        ),
      },
      {
        title: "Sumber Stok",
        key: "stockSource",
        width: 160,
        render: (_, record) => (
          <div className={workLogUiClassNames.stack}>
            <Tag className="ims-status-tag" color={getStockSourceTagColor(record.stockSourceType)}>
              {record.stockSourceType === "variant" ? "Variant" : "Master"}
            </Tag>
            {record.stockSourceType === "variant" && record.resolvedVariantLabel ? (
              <Typography.Text type="secondary" className={workLogUiClassNames.meta}>
                {record.resolvedVariantLabel}
              </Typography.Text>
            ) : null}
          </div>
        ),
      },
      {
        title: "Pemakaian",
        key: "qty",
        width: 180,
        render: (_, record) => (
          <Space direction="vertical" size={0}>
            <Typography.Text>
              Plan: {formatNumber(record.plannedQty)} {record.unit || ""}
            </Typography.Text>
            <Typography.Text type="secondary">
              Actual: {formatNumber(record.actualQty)} {record.unit || ""}
            </Typography.Text>
          </Space>
        ),
      },
      {
        title: "Biaya",
        key: "cost",
        width: 180,
        render: (_, record) => (
          <Space direction="vertical" size={0}>
            <Typography.Text>
              {formatCurrency(record.totalCostSnapshot || 0)}
            </Typography.Text>
            <Typography.Text type="secondary">
              Unit: {formatCurrency(record.costPerUnitSnapshot || 0)}
            </Typography.Text>
          </Space>
        ),
      },
    ],
    [getStockSourceTagColor, renderWorkLogCellBlock, workLogUiClassNames.meta, workLogUiClassNames.stack],
  );

  const detailOutputColumns = useMemo(
    () => [
      {
        title: "Output",
        key: "output",
        render: (_, record) => (
          renderWorkLogCellBlock(record.outputName || "-", [
            record.outputCode || "-",
            WORK_LOG_TARGET_TYPE_MAP[record.outputType] || record.outputType || "-",
            record.outputVariantLabel ? `Varian: ${record.outputVariantLabel}` : null,
          ])
        ),
      },
      {
        title: "Target Stok",
        key: "stockTarget",
        width: 170,
        render: (_, record) => (
          <div className={workLogUiClassNames.stack}>
            <Tag className="ims-status-tag" color={getStockSourceTagColor(record.stockSourceType)}>
              {record.stockSourceType === "variant" ? "Masuk ke Variant" : "Masuk ke Master"}
            </Tag>
            {record.outputVariantLabel ? (
              <Typography.Text type="secondary" className={workLogUiClassNames.meta}>
                {record.outputVariantLabel}
              </Typography.Text>
            ) : null}
          </div>
        ),
      },
      {
        title: "Hasil",
        key: "result",
        width: 180,
        render: (_, record) => (
          <Typography.Text>
            Good: {formatNumber(record.goodQty)} {record.unit || ""}
          </Typography.Text>
        ),
      },
      {
        title: "Mutasi Stok",
        key: "stockAdded",
        width: 150,
        render: (_, record) => (
          <Tag className="ims-status-tag" color={record.stockAdded ? "green" : "default"}>
            {record.stockAdded ? "Sudah masuk stok" : "Belum diposting"}
          </Tag>
        ),
      },
    ],
    [getStockSourceTagColor, renderWorkLogCellBlock, workLogUiClassNames.meta, workLogUiClassNames.stack],
  );

  // =====================================================
  // Kolom list Work Log Produksi
  // Fungsi blok:
  // - menampilkan work log aktif dalam tabel utama yang ringkas;
  // - menjaga tombol Detail/Edit/Selesaikan langsung terlihat tanpa scroll horizontal.
  // Alasan perubahan:
  // - regression UI sebelumnya memakai scroll x besar dan fixed action sehingga aksi terdorong ke kanan.
  // Status:
  // - aktif dipakai; handler aksi tetap sama dan tidak mengubah flow produksi.
  // =====================================================
  const columns = [
    {
      title: "No. Work Log",
      dataIndex: "workNumber",
      key: "workNumber",
      width: 105,
      render: (value) => (
        <Typography.Text strong>{resolveDisplayReference({ workNumber: value }, { fields: ["workNumber"], fallback: "-" })}</Typography.Text>
      ),
    },
    {
      title: "Tanggal",
      dataIndex: "workDate",
      key: "workDate",
      width: 130,
      render: (value) => formatDisplayDate(value),
    },
    {
      title: "Target / Tahapan",
      key: "targetStep",
      width: 240,
      render: (_, record) => (
        renderWorkLogCellBlock(record.targetName || "-", [
          record.stepName || "-",
          record.targetVariantLabel ? `Varian: ${record.targetVariantLabel}` : null,
          `No. Order: ${record.productionOrderCode || "-"}`,
        ])
      ),
    },
    {
      title: "Qty",
      key: "qty",
      width: 130,
      render: (_, record) => (
        <Space direction="vertical" size={0}>
          <Typography.Text>Batch: {formatNumber(record.plannedQty)}</Typography.Text>
          <Typography.Text type="secondary">Estimasi: {formatNumber(record.theoreticalOutputQty || 0)}</Typography.Text>
          <Typography.Text type="secondary">Hasil baik: {formatNumber(record.goodQty)}</Typography.Text>
        </Space>
      ),
    },
    {
      title: "Biaya Aktual",
      dataIndex: "totalCostActual",
      key: "totalCostActual",
      width: 95,
      render: (value) => formatCurrency(value),
    },
    {
      title: "Sumber",
      dataIndex: "sourceType",
      key: "sourceType",
      width: 105,
      render: (value) => (
        <Tag className="ims-status-tag" color={getWorkLogSourceTagColor(value)}>
          {WORK_LOG_SOURCE_TYPE_MAP[value] || value || "-"}
        </Tag>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 120,
      render: (value) => (
        <Tag className="ims-status-tag" color={getWorkLogStatusTagColor(value)}>
          {WORK_LOG_STATUS_MAP[value] || "-"}
        </Tag>
      ),
    },
    {
      title: "Aksi",
      key: "actions",
      width: 160,
      render: (_, record) => (
        // Aktif dipakai: tombol aksi disusun vertical compact agar tidak butuh scroll kanan.
        <Space direction="vertical" size={6} className="ims-action-group ims-action-group--vertical">
          <Button
            className="ims-action-button"
            size="small"
            icon={<EyeOutlined />}
            onClick={() => handleViewDetail(record)}
          >
            Detail
          </Button>

          {isEditableProductionWorkLog(record) && (
            <Button
              className="ims-action-button"
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEdit(record)}
            >
              Edit
            </Button>
          )}

          {isEditableProductionWorkLog(record) && (
            <Button
              className="ims-action-button"
              size="small"
              type="primary"
              onClick={() => handleOpenComplete(record)}
            >
              Selesaikan
            </Button>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div className="ims-page">
      <ProductionPageHeader
        title="Work Log Produksi"
        description="Realisasi kerja produksi dari order produksi. Work Log baru dibuat lewat tombol Mulai Produksi di menu Order Produksi."
      />

      <SummaryStatGrid
        items={summaryItems}
        className="ims-summary-row"
        gutter={[16, 16]}
      />

      <ProductionFilterCard>
          <Col xs={24} md={12}>
            <Input
              placeholder="Cari nomor, target, tahapan, PO..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              allowClear
            />
          </Col>

          <Col xs={24} md={12}>
            <Select
              className="ims-filter-control"
              value={statusFilter}
              onChange={setStatusFilter}
              options={[
                { value: "all", label: "Semua Status" },
                ...PRODUCTION_WORK_LOG_STATUSES,
              ]}
            />
          </Col>
      </ProductionFilterCard>

      <Card className="ims-section-card">
        {/* Aktif dipakai: scroll x besar dihapus agar aksi Work Log terlihat pada desktop/laptop normal. */}
        <DataRefreshIndicator loading={loading} dataSource={filteredData} />
        <Table
          className="ims-table"
          rowKey="id"
          columns={columns}
          dataSource={filteredData}
          locale={{
            emptyText: getDataTableEmptyText(loading, <Empty description="Belum ada data work log produksi" />),
          }}
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
          }}
        />
      </Card>

      <Drawer
        title={
          editingRecord?.id
            ? "Edit Work Log Produksi"
            : "Work Log dari Order Produksi"
        }
        open={formVisible}
        onClose={() => {
          setFormVisible(false);
          resetFormState();
        }}
        width={980}
        destroyOnClose
        extra={
          <Space>
            <Button
              onClick={() => {
                setFormVisible(false);
                resetFormState();
              }}
            >
              Batal
            </Button>
            <Button type="primary" loading={submitting} onClick={handleSubmit}>
              Simpan
            </Button>
          </Space>
        }
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            ...DEFAULT_PRODUCTION_WORK_LOG_FORM,
            workDate: dayjs(),
            sourceType: "production_order",
            status: "in_progress",
          }}
        >
          <Divider orientation="left">Informasi Dasar</Divider>

          <Row gutter={16}>
            <Col xs={24} md={8}>
              <Form.Item
                label="No. Work Log"
                name="workNumber"
              >
                <Input placeholder="Otomatis: JOB-DDMMYYYY-001" disabled />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                label="Tanggal"
                name="workDate"
                rules={[{ required: true, message: "Tanggal wajib diisi" }]}
              >
                <DatePicker style={{ width: "100%" }} format="DD/MM/YYYY" />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                label="Sumber Work Log"
                name="sourceType"
                tooltip="Work Log baru dibuat dari order produksi. Manual/Planned hanya pembacaan data lama."
              >
                <Select options={PRODUCTION_WORK_LOG_SOURCE_TYPES} disabled />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item shouldUpdate noStyle>
            {({ getFieldValue }) => {
              const sourceType = getFieldValue("sourceType");

              return (
                <>
                  {sourceType === "production_order" ? (
                    <Card size="small" style={{ marginBottom: 16 }}>
                      <Row gutter={16}>
                        <Col xs={24} md={18}>
                          <Form.Item
                            label="No. Order Produksi"
                            name="productionOrderId"
                          >
                            <Select
                              showSearch
                              optionFilterProp="label"
                              options={productionOrderOptions}
                              placeholder="Pilih order produksi..."
                              disabled={Boolean(editingRecord?.id)}
                              onChange={(value) => {
                                if (value) {
                                  handleApplyProductionOrderTemplate(value);
                                }
                              }}
                            />
                          </Form.Item>
                        </Col>

                        <Col xs={24} md={6}>
                          <Form.Item label=" ">
                            <Button
                              block
                              disabled={Boolean(editingRecord?.id)}
                              onClick={() => {
                                const orderId =
                                  form.getFieldValue("productionOrderId");
                                if (orderId) {
                                  handleApplyProductionOrderTemplate(orderId);
                                }
                              }}
                            >
                              Ambil Data PO
                            </Button>
                          </Form.Item>
                        </Col>
                      </Row>
                    </Card>
                  ) : null}

                  {sourceType === "planned" ? (
                    <Card size="small" style={{ marginBottom: 16 }}>
                      <Row gutter={16}>
                        <Col xs={24} md={18}>
                          <Form.Item label="Resep Produksi" name="bomId">
                            <Select
                              showSearch
                              optionFilterProp="label"
                              options={(referenceData.boms || []).map(
                                (item) => ({
                                  value: item.id,
                                  label: item.name || "-",
                                }),
                              )}
                              placeholder="Pilih resep produksi..."
                            />
                          </Form.Item>
                        </Col>

                        <Col xs={24} md={6}>
                          <Form.Item label=" ">
                            <Button
                              block
                              onClick={() => {
                                const bomId = form.getFieldValue("bomId");
                                if (bomId) {
                                  handleApplyBomTemplate(bomId);
                                }
                              }}
                            >
                              Ambil Data BOM
                            </Button>
                          </Form.Item>
                        </Col>
                      </Row>
                    </Card>
                  ) : null}
                </>
              );
            }}
          </Form.Item>

          <Divider orientation="left">Target & Tahapan</Divider>

          <Row gutter={16}>
            <Col xs={24} md={8}>
              <Form.Item
                label="Jenis Target"
                name="targetType"
                rules={[
                  { required: true, message: "Jenis target wajib dipilih" },
                ]}
              >
                <Select
                  options={[
                    { value: "semi_finished_material", label: "Bahan Produksi" },
                    { value: "product", label: "Produk Jadi" },
                  ]}
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={16}>
              <Form.Item
                label="Target Produksi"
                name="targetId"
                rules={[
                  { required: true, message: "Target produksi wajib dipilih" },
                ]}
              >
                <Select
                  showSearch
                  optionFilterProp="label"
                  options={getTargetOptions(targetTypeValue)}
                  placeholder="Pilih target produksi..."
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={24}>
              <Form.Item label="Profil Produksi" name="productionProfileId">
                <Select
                  showSearch
                  optionFilterProp="label"
                  options={getProductionProfileOptions(targetIdValue)}
                  placeholder="Pilih profil produksi untuk target ini..."
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={16}>
              <Form.Item
                label="Tahapan Produksi"
                name="stepId"
                rules={[{ required: true, message: "Tahapan wajib dipilih" }]}
              >
                <Select
                  showSearch
                  optionFilterProp="label"
                  options={stepOptions}
                  placeholder="Pilih tahapan..."
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item label="Sequence No" name="sequenceNo">
                <InputNumber min={1} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
          </Row>

          <Divider orientation="left">Qty & Operator</Divider>

          <Row gutter={16}>
            <Col xs={24} md={6}>
              <Form.Item
                label="Qty Batch"
                name="plannedQty"
                rules={[{ required: true, message: "Planned qty wajib diisi" }]}
              >
                <InputNumber min={1} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>

            <Col xs={24} md={6}>
              <Form.Item label="Qty Input Dasar" name="baseInputQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: '100%' }} />
              </Form.Item>
            </Col>

            <Col xs={24} md={6}>
              <Form.Item label="Sisa Daun Aktual" name="leftoverLeafQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: '100%' }} />
              </Form.Item>
            </Col>

            <Col xs={24} md={6}>
              <Form.Item label="Sisa Kawat Aktual" name="leftoverStemQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: '100%' }} />
              </Form.Item>
            </Col>

            <Col xs={24} md={6}>
              <Form.Item label="Good Qty" name="goodQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Form.Item name="rejectQty" hidden><InputNumber /></Form.Item>
            <Form.Item name="reworkQty" hidden><InputNumber /></Form.Item>

            <Col xs={24}>
              <Form.Item label="Worker" name="workerIds">
                <Select
                  mode="multiple"
                  showSearch
                  optionFilterProp="label"
                  options={employeeOptions}
                  placeholder="Pilih operator produksi..."
                />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item label="Sisa Setara Bunga Kelopak" name="leftoverPetalFlowerEquivalent">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: '100%' }} />
              </Form.Item>
            </Col>
          </Row>

          {selectedProductionProfile ? (
            <Card size="small" style={{ marginBottom: 16 }}>
              <Row gutter={[16, 16]}>
                <Col xs={24} md={8}><strong>Profil:</strong> {selectedProductionProfile.profileName || '-'}</Col>
                <Col xs={24} md={8}><strong>Teoritis Bunga:</strong> {formatNumber(monitoringPreview.theoreticalFlowerEquivalent || 0)}</Col>
                <Col xs={24} md={8}><strong>Miss %:</strong> {formatNumber(monitoringPreview.missPercent || 0)}%</Col>
                <Col xs={24} md={8}><strong>Miss Kelopak:</strong> {formatNumber(monitoringPreview.missPetalQty || 0)} pcs</Col>
                <Col xs={24} md={8}><strong>Miss Daun:</strong> {formatNumber(monitoringPreview.missLeafQty || 0)} pcs</Col>
                <Col xs={24} md={8}><strong>Miss Kawat:</strong> {formatNumber(monitoringPreview.missStemQty || 0)} pcs</Col>
              </Row>
            </Card>
          ) : null}

          <EditableLineSection
            title="Material Usages"
            description={editingRecord?.productionOrderId ? "Material dari PO terkunci agar pemakaian stok dan audit tidak berubah." : undefined}
            addButtonText="Tambah Material Usage"
            onAdd={() => openMaterialModal()}
            showAddButton={!editingRecord?.productionOrderId}
            dataSource={form.getFieldValue("materialUsages") || []}
            emptyText="Belum ada material usage"
            columns={[
              {
                title: "Item",
                key: "item",
                // =====================================================
                // AKTIF / GUARDED:
                // - metadata code/variant memakai class token global agar warna netral konsisten light/dark.
                // - hanya perubahan presentational; tidak mengubah payload work log, status, payroll, atau HPP.
                // =====================================================
                render: (_, record) => (
                  <div>
                    <div className={workLogUiClassNames.title}>{record.itemName || "-"}</div>
                    {record.resolvedVariantLabel ? (
                      <div className="ims-cell-meta">
                        Varian: {record.resolvedVariantLabel}
                      </div>
                    ) : null}
                  </div>
                ),
              },
              {
                title: "Qty",
                key: "qty",
                width: 180,
                render: (_, record) => (
                  <Space direction="vertical" size={0}>
                    <Typography.Text>
                      Plan: {formatNumber(record.plannedQty)}
                    </Typography.Text>
                    <Typography.Text type="secondary">
                      Actual: {formatNumber(record.actualQty)}
                    </Typography.Text>
                  </Space>
                ),
              },
              {
                title: "Total Cost",
                dataIndex: "totalCostSnapshot",
                width: 150,
                render: (value) => formatCurrency(value),
              },
              {
                title: "Aksi",
                width: 140,
                render: (_, record, index) => (
                  editingRecord?.productionOrderId ? (
                    <Typography.Text type="secondary" className="ims-cell-meta">Terkunci dari PO</Typography.Text>
                  ) : (
                    <Space direction="vertical" size={6} className="ims-action-group ims-action-group--vertical">
                      <Button className="ims-action-button" size="small" onClick={() => openMaterialModal(index, record)}>
                        Edit
                      </Button>
                      <Popconfirm
                        title="Hapus material usage ini?"
                        onConfirm={() => handleRemoveMaterialUsage(index)}
                        okText="Ya"
                        cancelText="Batal"
                      >
                        <Button className="ims-action-button" size="small" danger icon={<DeleteOutlined />} />
                      </Popconfirm>
                    </Space>
                  )
                ),
              },
            ]}
          />

          <EditableLineSection
            title="Outputs"
            description={editingRecord?.productionOrderId ? "Output dari PO terkunci. Isi Good Qty dari modal Selesaikan agar stok/HPP tetap konsisten." : undefined}
            addButtonText="Tambah Output"
            onAdd={() => openOutputModal()}
            showAddButton={!editingRecord?.productionOrderId}
            dataSource={form.getFieldValue("outputs") || []}
            emptyText="Belum ada output"
            columns={[
              {
                title: "Output",
                key: "output",
                render: (_, record) => (
                  <div>
                    <div className={workLogUiClassNames.title}>{record.outputName || "-"}</div>
                    <div className="ims-cell-meta">{record.outputCode || "-"}</div>
                    {record.outputVariantLabel ? (
                      <div className="ims-cell-meta">
                        Varian: {record.outputVariantLabel}
                      </div>
                    ) : null}
                  </div>
                ),
              },
              {
                title: "Qty",
                key: "qty",
                width: 180,
                render: (_, record) => (
                  <Typography.Text>
                    Good: {formatNumber(record.goodQty)}
                  </Typography.Text>
                ),
              },
              {
                title: "Aksi",
                width: 140,
                render: (_, record, index) => (
                  editingRecord?.productionOrderId ? (
                    <Typography.Text type="secondary" className="ims-cell-meta">Terkunci dari PO</Typography.Text>
                  ) : (
                    <Space direction="vertical" size={6} className="ims-action-group ims-action-group--vertical">
                      <Button className="ims-action-button" size="small" onClick={() => openOutputModal(index, record)}>
                        Edit
                      </Button>
                      <Popconfirm
                        title="Hapus output ini?"
                        onConfirm={() => handleRemoveOutput(index)}
                        okText="Ya"
                        cancelText="Batal"
                      >
                        <Button className="ims-action-button" size="small" danger icon={<DeleteOutlined />} />
                      </Popconfirm>
                    </Space>
                  )
                ),
              },
            ]}
          />

          <Divider orientation="left">Biaya & Catatan</Divider>

          <Row gutter={16}>
            <Col xs={24} md={4}>
              <Form.Item
                label="Biaya Tenaga Kerja"
                name="laborCostActual"
                tooltip="Biaya tenaga kerja aktif dibaca dari Payroll Produksi; estimasi tahapan hanya info."
              >
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} disabled />
              </Form.Item>
            </Col>

            <Col xs={24} md={4}>
              <Form.Item
                label="Biaya Overhead"
                name="overheadCostActual"
                tooltip="Overhead aktif berasal dari resep produksi untuk listrik/glue gun."
              >
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} disabled={Boolean(editingRecord?.productionOrderId)} />
              </Form.Item>
            </Col>

            <Form.Item name="scrapQty" hidden>
              <InputNumber />
            </Form.Item>

            <Col xs={24} md={16}>
              <Form.Item label="Catatan" name="notes">
                <Input.TextArea rows={2} placeholder="Catatan work log..." />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Drawer>

      <Drawer
        title="Detail Work Log Produksi"
        open={detailVisible}
        onClose={() => setDetailVisible(false)}
        width={980}
      >
        {!selectedRecord ? (
          <Empty description="Tidak ada data" />
        ) : (
          <>
            {/* ------------------------------------------------------------- */}
            {/* SECTION: ringkasan cepat untuk audit work log                 */}
            {/* Tujuan: user langsung tahu konteks kerja, status, dan hasil.  */}
            {/* ------------------------------------------------------------- */}
            <Space wrap size={[8, 8]} style={{ marginBottom: 16 }}>
              <Tag className="ims-status-tag" color={getWorkLogStatusTagColor(selectedRecord.status)}>
                {WORK_LOG_STATUS_MAP[selectedRecord.status] || "-"}
              </Tag>
              <Tag className="ims-status-tag" color={getWorkLogSourceTagColor(selectedRecord.sourceType)}>
                {WORK_LOG_SOURCE_TYPE_MAP[selectedRecord.sourceType] ||
                  selectedRecord.sourceType ||
                  "-"}
              </Tag>
              <Tag className="ims-status-tag">{selectedRecord.productionOrderCode || "Tanpa PO"}</Tag>
            </Space>

            {/* ------------------------------------------------------------- */}
            {/* SECTION: kartu ringkasan angka utama                          */}
            {/* Catatan maintainability:                                      */}
            {/* - kartu ini hanya presentasi cepat untuk user operasional     */}
            {/* - sumber data tetap berasal dari selectedRecord aktif         */}
            {/* ------------------------------------------------------------- */}
            <Row gutter={[12, 12]} style={{ marginBottom: 16 }}>
              {detailMetricCards.map((item) => (
                <Col xs={24} sm={12} xl={6} key={item.key}>
                  <Card size="small">
                    <Typography.Text type="secondary">
                      {item.label}
                    </Typography.Text>
                    <div className="ims-detail-value" style={{ marginTop: 6 }}>
                      {item.value}
                    </div>
                    <div className="ims-cell-meta" style={{ marginTop: 6 }}>
                      {item.helper}
                    </div>
                  </Card>
                </Col>
              ))}
            </Row>

            {/* ------------------------------------------------------------- */}
            {/* SECTION: informasi work log dan konteks produksi              */}
            {/* Dibagi 2 card agar lebih mudah dibaca daripada satu tabel     */}
            {/* deskripsi yang terlalu panjang dan padat.                     */}
            {/* ------------------------------------------------------------- */}
            <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
              <Col xs={24} xl={14}>
                <Card size="small" title="Ringkasan Work Log">
                  <Descriptions bordered size="small" column={1}>
                    <Descriptions.Item label="No. Work Log">
                      {resolveDisplayReference(selectedRecord, { fields: ["workNumber"], fallback: "-" })}
                    </Descriptions.Item>
                    <Descriptions.Item label="Tanggal">
                      {formatDisplayDate(selectedRecord.workDate)}
                    </Descriptions.Item>
                    <Descriptions.Item label="No. Order Produksi">
                      {selectedRecord.productionOrderCode || "-"}
                    </Descriptions.Item>
                    <Descriptions.Item label="Jenis Target">
                      {WORK_LOG_TARGET_TYPE_MAP[selectedRecord.targetType] || "-"}
                    </Descriptions.Item>
                    <Descriptions.Item label="Target">
                      <Space direction="vertical" size={0}>
                        <Typography.Text strong>
                          {selectedRecord.targetName || "-"}
                        </Typography.Text>
                        {selectedRecord.targetVariantLabel ? (
                          <Typography.Text type="secondary">
                            Varian: {selectedRecord.targetVariantLabel}
                          </Typography.Text>
                        ) : null}
                      </Space>
                    </Descriptions.Item>
                    <Descriptions.Item label="Tahapan">
                      {selectedRecord.stepName || "-"}
                    </Descriptions.Item>
                    <Descriptions.Item label="Profil Produksi">
                      {selectedRecord.productionProfileName || "-"}
                    </Descriptions.Item>
                  </Descriptions>
                </Card>
              </Col>

              <Col xs={24} xl={10}>
                <Space direction="vertical" size={16} style={{ width: "100%" }}>
                  <Card size="small" title="Tim & Catatan">
                    <Space direction="vertical" size={12} style={{ width: "100%" }}>
                      <div>
                        <Typography.Text type="secondary">
                          Operator Produksi
                        </Typography.Text>
                        <div style={{ marginTop: 8 }}>
                          {detailWorkerNames.length > 0 ? (
                            <Space wrap size={[8, 8]}>
                              {detailWorkerNames.map((name) => (
                                <Tag key={name} color="blue">
                                  {name}
                                </Tag>
                              ))}
                            </Space>
                          ) : (
                            <Typography.Text type="secondary">
                              Belum ada operator dipilih.
                            </Typography.Text>
                          )}
                        </div>
                      </div>

                      <Divider style={{ margin: 0 }} />

                      <div>
                        <Typography.Text type="secondary">
                          Catatan Eksekusi
                        </Typography.Text>
                        <div style={{ marginTop: 8 }}>
                          <Typography.Paragraph style={{ marginBottom: 0 }}>
                            {selectedRecord.notes || "Belum ada catatan work log."}
                          </Typography.Paragraph>
                        </div>
                      </div>
                    </Space>
                  </Card>

                  <Card size="small" title="Biaya Produksi">
                    <Row gutter={[12, 12]}>
                      <Col span={12}>
                        <Typography.Text type="secondary">Material</Typography.Text>
                        <div className="ims-cell-title" style={{ marginTop: 4 }}>
                          {formatCurrency(selectedRecord.materialCostActual || 0)}
                        </div>
                      </Col>
                      <Col span={12}>
                        <Typography.Text type="secondary">Tenaga Kerja</Typography.Text>
                        <div className="ims-cell-title" style={{ marginTop: 4 }}>
                          {formatCurrency(detailLaborDisplay)}
                        </div>
                        <Tag
                          className="ims-status-tag"
                          color={detailLaborCostDisplay.tagColor}
                          style={{ marginTop: 4 }}
                        >
                          {detailLaborCostDisplay.label}
                        </Tag>
                        <div className="ims-cell-meta" style={{ marginTop: 4 }}>
                          {detailLaborCostDisplay.helper}
                        </div>
                      </Col>
                      <Col span={12}>
                        <Typography.Text type="secondary">Overhead</Typography.Text>
                        <div className="ims-cell-title" style={{ marginTop: 4 }}>
                          {formatCurrency(detailOverheadCostDisplay.amount)}
                        </div>
                        <Tag
                          className="ims-status-tag"
                          color={detailOverheadCostDisplay.tagColor}
                          style={{ marginTop: 4 }}
                        >
                          {detailOverheadCostDisplay.label}
                        </Tag>
                        <div className="ims-cell-meta" style={{ marginTop: 4 }}>
                          {detailOverheadCostDisplay.helper}
                        </div>
                      </Col>

                    </Row>
                  </Card>
                </Space>
              </Col>
            </Row>

            {/* ------------------------------------------------------------- */}
            {/* SECTION: tabel pemakaian material                              */}
            {/* Fokus ke item, sumber stok, qty pakai, dan biaya snapshot.    */}
            {/* ------------------------------------------------------------- */}
            <Card size="small" title="Pemakaian Material" style={{ marginBottom: 16 }}>
              <Table
                className="ims-table"
                rowKey={(record, index) => record.id || `material-${index}`}
                pagination={false}
                size="small"
                dataSource={selectedRecord.materialUsages || []}
                locale={{ emptyText: "Belum ada material usage" }}
                columns={detailMaterialColumns}
              />
            </Card>

            {/* ------------------------------------------------------------- */}
            {/* SECTION: tabel hasil produksi                                  */}
            {/* Tujuan: user mudah audit output, variant target, dan status   */}
            {/* posting stok setelah work log selesai.                        */}
            {/* ------------------------------------------------------------- */}
            <Card size="small" title="Hasil Produksi">
              <Table
                className="ims-table"
                rowKey={(record, index) => record.id || `output-${index}`}
                pagination={false}
                size="small"
                dataSource={selectedRecord.outputs || []}
                locale={{ emptyText: "Belum ada output" }}
                columns={detailOutputColumns}
              />
            </Card>
          </>
        )}
      </Drawer>

      <Modal
        title={
          editingMaterialIndex !== null
            ? "Edit Material Usage"
            : "Tambah Material Usage"
        }
        open={materialModalVisible}
        onCancel={() => {
          setMaterialModalVisible(false);
          setEditingMaterialIndex(null);
          materialForm.resetFields();
        }}
        onOk={handleSaveMaterialUsage}
        okText="Simpan"
        destroyOnClose
      >
        <Form
          form={materialForm}
          layout="vertical"
          initialValues={DEFAULT_WORK_LOG_MATERIAL_USAGE}
        >
          <Form.Item
            label="Item Type"
            name="itemType"
            rules={[{ required: true, message: "Item type wajib dipilih" }]}
          >
            <Select
              options={[
                { value: "raw_material", label: "Raw Material" },
                { value: "semi_finished_material", label: "Bahan Produksi" },
              ]}
            />
          </Form.Item>

          <Form.Item shouldUpdate noStyle>
            {({ getFieldValue, setFieldValue }) => {
              const itemType = getFieldValue("itemType");
              return (
                <Form.Item
                  label="Item"
                  name="itemId"
                  rules={[{ required: true, message: "Item wajib dipilih" }]}
                >
                  <Select
                    showSearch
                    optionFilterProp="label"
                    options={getMaterialOptions(itemType)}
                    placeholder="Pilih item..."
                    onChange={() => {
                      setFieldValue("resolvedVariantKey", undefined);
                      setFieldValue("resolvedVariantLabel", "");
                    }}
                  />
                </Form.Item>
              );
            }}
          </Form.Item>

          <Form.Item shouldUpdate noStyle>
            {({ getFieldValue, setFieldValue }) => {
              const itemType = getFieldValue("itemType");
              const itemId = getFieldValue("itemId");
              const selectedItem = getMaterialOptions(itemType).find((item) => item.value === itemId)?.raw;
              const hasVariants = inferHasVariants(selectedItem || {});
              const variantOptions = buildVariantOptionsFromItem(selectedItem || {});

              if (!hasVariants) return null;

              return (
                <Form.Item
                  label="Varian Material"
                  name="resolvedVariantKey"
                  rules={[{ required: true, message: "Varian material wajib dipilih" }]}
                >
                  <Select
                    showSearch
                    optionFilterProp="label"
                    options={variantOptions}
                    placeholder="Pilih varian material..."
                    onChange={(value) => {
                      const selectedVariant = variantOptions.find((item) => item.value === value);
                      setFieldValue("resolvedVariantLabel", selectedVariant?.label || "");
                    }}
                  />
                </Form.Item>
              );
            }}
          </Form.Item>

          <Row gutter={12}>
            <Col span={8}>
              <Form.Item label="Qty Batch" name="plannedQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="Actual Qty" name="actualQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="Unit" name="unit">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item label="Cost / Unit Snapshot" name="costPerUnitSnapshot">
            <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
          </Form.Item>

          <Form.Item label="Catatan" name="notes">
            <Input.TextArea rows={2} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title={editingOutputIndex !== null ? "Edit Output" : "Tambah Output"}
        open={outputModalVisible}
        onCancel={() => {
          setOutputModalVisible(false);
          setEditingOutputIndex(null);
          outputForm.resetFields();
        }}
        onOk={handleSaveOutput}
        okText="Simpan"
        destroyOnClose
      >
        <Form
          form={outputForm}
          layout="vertical"
          initialValues={DEFAULT_WORK_LOG_OUTPUT}
        >
          <Form.Item
            label="Output Type"
            name="outputType"
            rules={[{ required: true, message: "Output type wajib dipilih" }]}
          >
            <Select
              options={[
                { value: "semi_finished_material", label: "Bahan Produksi" },
                { value: "product", label: "Produk Jadi" },
              ]}
            />
          </Form.Item>

          <Form.Item shouldUpdate noStyle>
            {({ getFieldValue, setFieldValue }) => {
              const outputType = getFieldValue("outputType");

              const options =
                outputType === "semi_finished_material"
                  ? (referenceData.semiFinishedMaterials || []).map((item) => ({
                      value: item.id,
                      label: item.name || "-",
                      raw: item,
                    }))
                  : (referenceData.products || []).map((item) => ({
                      value: item.id,
                      label: item.name || "-",
                      raw: item,
                    }));

              return (
                <Form.Item
                  label="Output Item"
                  name="outputIdRef"
                  rules={[
                    { required: true, message: "Output item wajib dipilih" },
                  ]}
                >
                  <Select
                    showSearch
                    optionFilterProp="label"
                    options={options}
                    placeholder="Pilih output item..."
                    onChange={() => {
                      setFieldValue("outputVariantKey", undefined);
                      setFieldValue("outputVariantLabel", "");
                    }}
                  />
                </Form.Item>
              );
            }}
          </Form.Item>

          <Form.Item shouldUpdate noStyle>
            {({ getFieldValue, setFieldValue }) => {
              const outputType = getFieldValue("outputType");
              const outputIdRef = getFieldValue("outputIdRef");
              const selectedOutput = (
                outputType === "semi_finished_material"
                  ? (referenceData.semiFinishedMaterials || [])
                  : (referenceData.products || [])
              ).find((item) => item.id === outputIdRef);
              const hasVariants = inferHasVariants(selectedOutput || {});
              const variantOptions = buildVariantOptionsFromItem(selectedOutput || {});

              if (!hasVariants) return null;

              return (
                <Form.Item
                  label="Varian Output"
                  name="outputVariantKey"
                  rules={[{ required: true, message: "Varian output wajib dipilih" }]}
                >
                  <Select
                    showSearch
                    optionFilterProp="label"
                    options={variantOptions}
                    placeholder="Pilih varian output..."
                    onChange={(value) => {
                      const selectedVariant = variantOptions.find((item) => item.value === value);
                      setFieldValue("outputVariantLabel", selectedVariant?.label || "");
                    }}
                  />
                </Form.Item>
              );
            }}
          </Form.Item>

          <Row gutter={12}>
            <Col span={24}>
              <Form.Item label="Good Qty" name="goodQty">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item name="rejectQty" hidden><InputNumber /></Form.Item>
          <Form.Item name="reworkQty" hidden><InputNumber /></Form.Item>

          <Row gutter={12}>
            <Col span={12}>
              <Form.Item label="Cost / Unit" name="costPerUnit">
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Unit" name="unit">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item label="Catatan" name="notes">
            <Input.TextArea rows={2} />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title="Selesaikan Work Log Produksi"
        open={completeModalVisible}
        onCancel={() => {
          setCompleteModalVisible(false);
          setCompletingRecord(null);
          completeForm.resetFields();
        }}
        onOk={handleMarkCompleted}
        okText="Selesaikan"
        destroyOnClose
      >
        {/* Aktif dipakai: konteks estimasi output ditampilkan kembali sebelum input hasil produksi. */}
        {renderCompleteWorkLogEstimateInfo(completingRecord)}

        <Form form={completeForm} layout="vertical">
          <Row gutter={12}>
            <Col span={24}>
              <Form.Item
                label="Good Qty"
                name="goodQty"
                rules={[{ required: true, message: "Good qty wajib diisi" }]}
              >
                <InputNumber min={0} step={1} precision={0} parser={parseIntegerIdInput} style={{ width: "100%" }} />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            label="Operator Produksi"
            name="workerIds"
            rules={[
              {
                required: true,
                type: "array",
                min: 1,
                message: "Operator Produksi wajib dipilih agar payroll otomatis bisa dibuat",
              },
            ]}
          >
            <Select
              mode="multiple"
              optionFilterProp="label"
              options={employeeOptions}
              placeholder="Pilih operator yang mengerjakan work log ini..."
            />
          </Form.Item>

          <Form.Item label="Catatan Penyelesaian" name="notes">
            <Input.TextArea
              rows={3}
              placeholder="Catatan hasil produksi, miss, atau kendala proses..."
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default ProductionWorkLogs;
