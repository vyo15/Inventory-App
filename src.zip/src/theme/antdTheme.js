import { theme } from "antd";

// =========================
// SECTION: Ant Design Theme Generator
// Fungsi:
// - menjadi pusat token light/dark mode Ant Design
// - dark mode dibuat lebih netral agar nyaman dipakai lama
// - warna biru dipakai sebagai aksen aktif, bukan warna semua permukaan
// Catatan:
// - file ini masih dipakai langsung oleh ConfigProvider, jadi semua perubahan token
//   di sini akan mempengaruhi komponen global yang memakai theme antd
// =========================
export const getAntdTheme = (darkTheme = false) => {
  return {
    algorithm: darkTheme ? theme.darkAlgorithm : theme.defaultAlgorithm,
    token: {
      colorPrimary: "#3b82f6",
      fontFamily: 'Inter, "Segoe UI", sans-serif',
      borderRadius: 14,
      colorBgBase: darkTheme ? "#0b1220" : "#f3f6fb",
      colorBgLayout: darkTheme ? "#0b1220" : "#f3f6fb",
      colorBgContainer: darkTheme ? "#111827" : "#ffffff",
      colorBgElevated: darkTheme ? "#111827" : "#ffffff",
      colorTextBase: darkTheme ? "#e5e7eb" : "#0f172a",
      colorTextSecondary: darkTheme
        ? "rgba(148, 163, 184, 0.92)"
        : "rgba(15, 23, 42, 0.72)",
      colorBorder: darkTheme
        ? "rgba(148, 163, 184, 0.14)"
        : "rgba(15, 23, 42, 0.08)",
      colorBorderSecondary: darkTheme
        ? "rgba(148, 163, 184, 0.10)"
        : "rgba(15, 23, 42, 0.06)",
    },
    components: {
      Layout: {
        bodyBg: "transparent",
        siderBg: darkTheme ? "#0f172a" : "#ffffff",
        headerBg: "transparent",
        triggerBg: darkTheme ? "#0f172a" : "#ffffff",
        triggerColor: darkTheme ? "#e5e7eb" : "#0f172a",
      },
      Menu: {
        itemBorderRadius: 14,
        subMenuItemBorderRadius: 12,
        itemHeight: 44,
        iconSize: 17,
        colorItemBgSelected: darkTheme
          ? "rgba(59, 130, 246, 0.16)"
          : "rgba(37, 99, 235, 0.14)",
        colorItemTextSelected: darkTheme ? "#f8fafc" : "#0f172a",
        colorItemTextHover: darkTheme ? "#f8fafc" : "#0f172a",
      },
      Card: {
        borderRadiusLG: 18,
        colorBgContainer: darkTheme ? "#111827" : "#ffffff",
      },
      Button: {
        borderRadius: 12,
        defaultBg: darkTheme ? "#111827" : "#ffffff",
        defaultBorderColor: darkTheme
          ? "rgba(148, 163, 184, 0.14)"
          : "rgba(15, 23, 42, 0.08)",
        defaultColor: darkTheme ? "#e5e7eb" : "#0f172a",
      },
      Input: {
        borderRadius: 12,
      },
      Select: {
        borderRadius: 12,
      },
      Table: {
        headerBorderRadius: 12,
      },

      // =========================
      // SECTION: Tag Tokens
      // Fungsi:
      // - memperbaiki label/tag default agar tetap terbaca di dark mode
      // - terutama untuk chip stok varian yang memakai <Tag> tanpa color khusus
      // Catatan:
      // - token ini masih dipakai oleh tag default Ant Design
      // - tag berwarna khusus tetap boleh memakai style bawaan / color explicit
      // =========================
      Tag: {
        defaultBg: darkTheme ? "rgba(255, 255, 255, 0.04)" : "#ffffff",
        defaultColor: darkTheme ? "#dbe4ee" : "#334155",
      },
    },
  };
};
